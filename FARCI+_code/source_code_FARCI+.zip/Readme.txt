**********************************
**     CODE of FARCI+       **
**********************************

1.- The folder "src" contains three sub-folders: "FARCHD", "keel" and "org".
2.- The code of the FARCI+ method is allocated in the "FARCHD" folder. The folder is named FARCHD because it the base classifier which is modified as explained in the IEEE Transactions on Fuzzy Systems paper to reach the FARCI+ method.
3.- The sub-folders "keel" and "org" are necessary because they contain some functions used by FARCI+.
4.- In order to compile FARCI+, you have to create a java application with existing source code and add the folder src (with all its sob-folders).

**********************************
**         EXECUTIONS           **
**********************************

1.- The folder named "execution" contains the structure used by the KEEL software to run experiments. This is an example of the execution of FARCI+ with the "iris0" dataset.
It contains the following folders:
      + datasets: inside there is the data of the different datasets (a sub-folder per dataset with the corresponding dataset's name).
	  + exe: the executable of FARCI ("FARCI+.jar") is allocated in this folder.
	  + results: the results are stored in the folder named wangMendel. This folder has to have as many sub-folders as datasets considered in the study. This sub-folders are named with the name of the datasets.
	  + scripts:
		* The datasets used in the execution are defined in the file named "RunKeel.xml".
		* Folder "wangMendel": it has as many sub-folders as datasets used in the experiment. Inside each sob-folder it is specified the configuration of the FARCI+ method for each folder of the 5-fcv scheme.
		                       In the configuration files of the "iris0" example it is shown the seed used to obtain the results of the IEEE TFS paper with the best configuration of the method.  
2.- To execute FARCI+ you have to go to the folder named "scripts" and run: "java -jar RunKeel.jar". It will execute the datasets specified in the "RunKeel.xml" file.
3.- To include more datasets:
      + It is necessary to include them in the "RunKeel.xml" file. Follow the structure shown in the "iris0" example.
	  + It is necessary to specify the configuration for the datasets. Follow the structure like the one shown for the "iris0" dataset ("\scripts\wangMendel\iris0\").
	  + It is necessary to create a folder named as the dataset in "results\wangMendel\" folder.
4.- To execute a modification of FARCI+, you have to change the FARCI+'s code, compile it and put the new executable (named "FARCI+.jar") in the exe folder. 
If the executable is not named "FARCI+.jar" you have to write the new executable name in the "RunKeel.xml" file.