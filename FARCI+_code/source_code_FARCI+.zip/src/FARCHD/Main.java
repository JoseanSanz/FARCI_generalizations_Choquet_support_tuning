package FARCHD;

public class Main {
  private parseParameters parameters;
  
  private void execute(String confFile) {
    this.parameters = new parseParameters();
    this.parameters.parseConfigurationFile(confFile);
    Bull method = new Bull(this.parameters);
    method.execute();
  }
  
  public static void main(String[] args) {
    Main program = new Main();
    System.out.println("Executing Algorithm.");
    program.execute(args[0]);
  }
}
