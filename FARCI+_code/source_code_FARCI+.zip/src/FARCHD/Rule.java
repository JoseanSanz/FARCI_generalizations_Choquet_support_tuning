package FARCHD;

import java.util.ArrayList;

public class Rule implements Comparable {
  int[] antecedent;
  
  int clas;
  
  int nAnts;
  
  double conf;
  
  double supp;
  
  double suppAnt;
  
  double wracc;
  
  double lift;
  
  DataBase dataBase;
  
  public Rule(Rule r) {
    this.antecedent = new int[r.antecedent.length];
    for (int k = 0; k < this.antecedent.length; k++)
      this.antecedent[k] = r.antecedent[k]; 
    this.clas = r.clas;
    this.dataBase = r.dataBase;
    this.conf = r.conf;
    this.supp = r.supp;
    this.lift = r.lift;
    this.suppAnt = r.suppAnt;
    this.nAnts = r.nAnts;
    this.wracc = r.wracc;
  }
  
  public Rule(DataBase dataBase) {
    this.antecedent = new int[dataBase.numVariables()];
    for (int i = 0; i < this.antecedent.length; i++)
      this.antecedent[i] = -1; 
    this.clas = -1;
    this.dataBase = dataBase;
    this.conf = 0.0D;
    this.supp = 0.0D;
    this.lift = 0.0D;
    this.suppAnt = 0.0D;
    this.nAnts = 0;
    this.wracc = 0.0D;
  }
  
  public Rule clone() {
    Rule r = new Rule(this.dataBase);
    r.antecedent = new int[this.antecedent.length];
    for (int i = 0; i < this.antecedent.length; i++)
      r.antecedent[i] = this.antecedent[i]; 
    r.clas = this.clas;
    r.dataBase = this.dataBase;
    r.conf = this.conf;
    r.supp = this.supp;
    r.lift = this.lift;
    r.suppAnt = this.suppAnt;
    r.nAnts = this.nAnts;
    r.wracc = this.wracc;
    return r;
  }
  
  public void asignaAntecedente(int[] antecedent) {
    this.nAnts = 0;
    for (int i = 0; i < antecedent.length; i++) {
      this.antecedent[i] = antecedent[i];
      if (this.antecedent[i] > -1)
        this.nAnts++; 
    } 
  }
  
  public void setConsequent(int clas) {
    this.clas = clas;
  }
  
  public void setSupportAntecedent(double supportAnt) {
    this.suppAnt = supportAnt;
  }
  
  public double matching(double[] example, int typeRW, int typeAggMatch, int tuneCut) {
    return degreeProduct(example, typeRW, typeAggMatch, tuneCut);
  }
  
  public double matchingAnt(double[] example) {
    double degree = 1.0D;
    for (int i = 0; i < this.antecedent.length && degree > 0.0D; ) {
      degree *= this.dataBase.matching(i, this.antecedent[i], example[i]);
      i++;
    } 
    return degree;
  }
  
  public double matchingAnt(double[] example, int typeAggMatch, int tuneCut) {
    double degree, arithmeticMean = 1.0D;
    if (tuneCut == 1) {
      arithmeticMean = 0.0D;
      double nAnts = 0.0D;
      for (int i = 0; i < this.antecedent.length; i++) {
        if (this.antecedent[i] > -1) {
          double machDegree = this.dataBase.matching(i, this.antecedent[i], example[i]);
          nAnts++;
          if (machDegree == 0.0D) {
            arithmeticMean = 0.0D;
            break;
          } 
          arithmeticMean += machDegree;
        } 
      } 
      arithmeticMean /= nAnts;
    } 
    if ((((tuneCut == 1) ? 1 : 0) & ((arithmeticMean < this.dataBase.cut[this.clas]) ? 1 : 0)) != 0) {
      degree = 0.0D;
    } else if (typeAggMatch == 0) {
      degree = 1.0D;
      for (int i = 0; i < this.antecedent.length && degree > 0.0D; ) {
        degree *= this.dataBase.matching(i, this.antecedent[i], example[i]);
        i++;
      } 
    } else if (typeAggMatch == 1) {
      if (tuneCut == 1) {
        degree = arithmeticMean;
      } else {
        degree = 0.0D;
        double nAnts = 0.0D;
        for (int i = 0; i < this.antecedent.length; i++) {
          if (this.antecedent[i] > -1) {
            double machDegree = this.dataBase.matching(i, this.antecedent[i], example[i]);
            nAnts++;
            if (machDegree == 0.0D) {
              degree = 0.0D;
              break;
            } 
            degree += machDegree;
          } 
        } 
        degree /= nAnts;
      } 
    } else if (typeAggMatch == 2) {
      degree = 1.0D;
      double nAnts = 0.0D;
      for (int i = 0; i < this.antecedent.length && degree > 0.0D; i++) {
        if (this.antecedent[i] > -1) {
          degree *= this.dataBase.matching(i, this.antecedent[i], example[i]);
          nAnts++;
        } 
      } 
      degree = Math.pow(degree, 1.0D / nAnts);
    } else {
      degree = 0.0D;
      double nAnts = 0.0D;
      for (int i = 0; i < this.antecedent.length; i++) {
        if (this.antecedent[i] > -1) {
          double machDegree = this.dataBase.matching(i, this.antecedent[i], example[i]);
          nAnts++;
          if (machDegree == 0.0D) {
            degree = 0.0D;
            break;
          } 
          degree += 1.0D / machDegree;
        } 
      } 
      if (degree != 0.0D)
        degree = nAnts / degree; 
    } 
    return degree;
  }
  
  private double degreeProduct(double[] example, int typeRW, int typeAggMatch, int tuneCut) {
    double degree, arithmeticMean = 1.0D;
    if (tuneCut == 1) {
      arithmeticMean = 0.0D;
      double nAnts = 0.0D;
      for (int i = 0; i < this.antecedent.length; i++) {
        if (this.antecedent[i] > -1) {
          double machDegree = this.dataBase.matching(i, this.antecedent[i], example[i]);
          nAnts++;
          if (machDegree == 0.0D) {
            arithmeticMean = 0.0D;
            break;
          } 
          arithmeticMean += machDegree;
        } 
      } 
      arithmeticMean /= nAnts;
    } 
    if ((((tuneCut == 1) ? 1 : 0) & ((arithmeticMean < this.dataBase.cut[this.clas]) ? 1 : 0)) != 0) {
      degree = 0.0D;
    } else if (typeAggMatch == 0) {
      degree = 1.0D;
      for (int i = 0; i < this.antecedent.length && degree > 0.0D; ) {
        degree *= this.dataBase.matching(i, this.antecedent[i], example[i]);
        i++;
      } 
    } else if (typeAggMatch == 1) {
      if (tuneCut == 1) {
        degree = arithmeticMean;
      } else {
        degree = 0.0D;
        double nAnts = 0.0D;
        for (int i = 0; i < this.antecedent.length; i++) {
          if (this.antecedent[i] > -1) {
            double machDegree = this.dataBase.matching(i, this.antecedent[i], example[i]);
            nAnts++;
            if (machDegree == 0.0D) {
              degree = 0.0D;
              break;
            } 
            degree += machDegree;
          } 
        } 
        degree /= nAnts;
      } 
    } else if (typeAggMatch == 2) {
      degree = 1.0D;
      double nAnts = 0.0D;
      for (int i = 0; i < this.antecedent.length && degree > 0.0D; i++) {
        if (this.antecedent[i] > -1) {
          degree *= this.dataBase.matching(i, this.antecedent[i], example[i]);
          nAnts++;
        } 
      } 
      degree = Math.pow(degree, 1.0D / nAnts);
    } else {
      degree = 0.0D;
      double nAnts = 0.0D;
      for (int i = 0; i < this.antecedent.length; i++) {
        if (this.antecedent[i] > -1) {
          double machDegree = this.dataBase.matching(i, this.antecedent[i], example[i]);
          nAnts++;
          if (machDegree == 0.0D) {
            degree = 0.0D;
            break;
          } 
          degree += 1.0D / machDegree;
        } 
      } 
      if (degree != 0.0D)
        degree = nAnts / degree; 
    } 
    double weight = (typeRW == 0) ? this.conf : ((typeRW == 1) ? this.lift : (this.conf * this.lift));
    return degree * weight;
  }
  
  public void setConfidence(double conf) {
    this.conf = conf;
  }
  
  public void setSupport(double supp) {
    this.supp = supp;
  }
  
  public void setLift(double lift) {
    this.lift = lift;
  }
  
  public void setWracc(double wracc) {
    this.wracc = wracc;
  }
  
  public double getConfidence() {
    return this.conf;
  }
  
  public double getSupport() {
    return this.supp;
  }
  
  public double getSupportAnt() {
    return this.suppAnt;
  }
  
  public double getLift() {
    return this.lift;
  }
  
  public double getWracc() {
    return this.wracc;
  }
  
  public int getClas() {
    return this.clas;
  }
  
  public boolean isSubset(Rule a) {
    if (this.clas != a.clas || this.nAnts > a.nAnts)
      return false; 
    for (int k = 0; k < this.antecedent.length; ) {
      if (this.antecedent[k] <= -1 || this.antecedent[k] == a.antecedent[k]) {
        k++;
        continue;
      } 
      return false;
    } 
    return true;
  }
  
  public void calculateWracc(myDataset train, ArrayList<ExampleWeight> exampleWeight, int typeAggMatch, int tuneCut) {
    double n_AC = 0.0D;
    double n_A = 0.0D;
    double n_C = 0.0D;
    for (int i = 0; i < train.size(); i++) {
      ExampleWeight ex = exampleWeight.get(i);
      if (ex.isActive()) {
        double degree = matchingAnt(train.getExample(i), typeAggMatch, tuneCut);
        if (degree > 0.0D) {
          n_A += degree *= ex.getWeight();
          if (train.getOutputAsInteger(i) == this.clas) {
            n_AC += degree;
            n_C += ex.getWeight();
          } 
        } else if (train.getOutputAsInteger(i) == this.clas) {
          n_C += ex.getWeight();
        } 
      } 
    } 
    this.wracc = (n_A < 1.0E-10D || n_AC < 1.0E-10D || n_C < 1.0E-10D) ? -1.0D : (n_AC / n_C * (n_AC / n_A - train.frecuentClass(this.clas)));
  }
  
  public void calculateWracc(myDataset train, ArrayList<ExampleWeight> exampleWeight) {
    double n_AC = 0.0D;
    double n_A = 0.0D;
    double n_C = 0.0D;
    for (int i = 0; i < train.size(); i++) {
      ExampleWeight ex = exampleWeight.get(i);
      if (ex.isActive()) {
        double degree = matchingAnt(train.getExample(i));
        if (degree > 0.0D) {
          n_A += degree *= ex.getWeight();
          if (train.getOutputAsInteger(i) == this.clas) {
            n_AC += degree;
            n_C += ex.getWeight();
          } 
        } else if (train.getOutputAsInteger(i) == this.clas) {
          n_C += ex.getWeight();
        } 
      } 
    } 
    this.wracc = (n_A < 1.0E-10D || n_AC < 1.0E-10D || n_C < 1.0E-10D) ? -1.0D : (n_AC / n_C * (n_AC / n_A - train.frecuentClass(this.clas)));
  }
  
  public int reduceWeight(myDataset train, ArrayList<ExampleWeight> exampleWeight, int typeAggMatch, int tuneCut) {
    int count = 0;
    for (int i = 0; i < train.size(); i++) {
      ExampleWeight ex = exampleWeight.get(i);
      if (ex.isActive() && matchingAnt(train.getExample(i), typeAggMatch, tuneCut) > 0.0D) {
        ex.incCount();
        if (!ex.isActive() && train.getOutputAsInteger(i) == this.clas)
          count++; 
      } 
    } 
    return count;
  }
  
  public int reduceWeightClass(myDataset train, ArrayList<ExampleWeight> exampleWeight, int typeAggMatch, int tuneCut) {
    int count = 0;
    for (int i = 0; i < train.size(); i++) {
      ExampleWeight ex = exampleWeight.get(i);
      if (ex.isActive() && train.getOutputAsInteger(i) == this.clas && matchingAnt(train.getExample(i), typeAggMatch, tuneCut) > 0.0D) {
        ex.incCount();
        if (!ex.isActive())
          count++; 
      } 
    } 
    return count;
  }
  
  public int reduceWeight(myDataset train, ArrayList<ExampleWeight> exampleWeight) {
    int count = 0;
    for (int i = 0; i < train.size(); i++) {
      ExampleWeight ex = exampleWeight.get(i);
      if (ex.isActive() && matchingAnt(train.getExample(i)) > 0.0D) {
        ex.incCount();
        if (!ex.isActive() && train.getOutputAsInteger(i) == this.clas)
          count++; 
      } 
    } 
    return count;
  }
  
  public void setLabel(int pos, int label) {
    if (this.antecedent[pos] < 0 && label > -1)
      this.nAnts++; 
    if (this.antecedent[pos] > -1 && label < 0)
      this.nAnts--; 
    this.antecedent[pos] = label;
  }
  
  public int compareTo(Object a) {
    if (((Rule)a).wracc < this.wracc)
      return -1; 
    if (((Rule)a).wracc > this.wracc)
      return 1; 
    return 0;
  }
}
