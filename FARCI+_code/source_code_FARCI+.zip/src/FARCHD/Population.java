package FARCHD;

import java.util.ArrayList;
import java.util.Collections;
import org.core.Randomize;

public class Population {
  ArrayList<Individual> Population;
  
  double alpha;
  
  double w1;
  
  double L;
  
  double Lini;
  
  int n_variables;
  
  int pop_size;
  
  int maxTrials;
  
  int nTrials;
  
  int BITS_GEN;
  
  int numReiniciosSinMejora;
  
  int tuneCut;
  
  double best_fitness;
  
  double best_accuracy;
  
  double bestFitness;
  
  int[] selected;
  
  String evolution;
  
  myDataset train;
  
  DataBase dataBase;
  
  RuleBase ruleBase;
  
  public boolean BETTER(double a, double b) {
    return (a > b);
  }
  
  public Population() {}
  
  public Population(myDataset train, DataBase dataBase, RuleBase ruleBase, int size, int BITS_GEN, int maxTrials, double alpha, int tuneCut) {
    this.dataBase = dataBase;
    this.train = train;
    this.ruleBase = ruleBase;
    this.BITS_GEN = BITS_GEN;
    this.n_variables = dataBase.numVariables();
    this.pop_size = size;
    this.alpha = alpha;
    this.maxTrials = maxTrials;
    double numGenes = dataBase.getnLabelsReal();
    switch (this.ruleBase.typeInference) {
      case 2:
        numGenes = (dataBase.getnLabelsReal() + dataBase.n_classes);
        break;
      case 4:
        numGenes = (dataBase.getnLabelsReal() + dataBase.n_variables * 2 + dataBase.n_classes);
      case 5:
        numGenes = (dataBase.getnLabelsReal() + dataBase.n_variables * 3 + dataBase.n_classes);
      case 6:
        numGenes = (dataBase.getnLabelsReal() * 2 + dataBase.n_classes);
      case 7:
        numGenes = (dataBase.getnLabelsReal() * 2);
        break;
    } 
    this.L = this.Lini = (numGenes * BITS_GEN + ruleBase.size()) / 4.0D;
    this.w1 = this.alpha * ruleBase.size();
    this.numReiniciosSinMejora = 0;
    this.bestFitness = 0.0D;
    this.tuneCut = tuneCut;
    this.Population = new ArrayList<>();
    this.selected = new int[this.pop_size];
    this.evolution = "";
  }
  
  public void Generation() {
    init();
    evaluate(0);
    do {
      selection();
      crossover();
      evaluate(this.pop_size);
      elitist();
      if (hasNew())
        continue; 
      this.L -= 30.0D;
      if (this.L >= 0.0D)
        continue; 
      System.out.println("Restart");
      restart();
      if (((Individual)this.Population.get(0)).fitness <= this.bestFitness) {
        this.numReiniciosSinMejora++;
      } else {
        this.bestFitness = ((Individual)this.Population.get(0)).fitness;
        this.numReiniciosSinMejora = 0;
      } 
    } while (this.nTrials < this.maxTrials && this.numReiniciosSinMejora < 3 && ((Individual)this.Population.get(0)).fitness < 1.0D);
  }
  
  private void init() {
    Individual ind = new Individual(this.ruleBase, this.dataBase, this.w1, this.tuneCut);
    ind.reset();
    this.Population.add(ind);
    int i;
    for (i = 1; i < this.pop_size; i++) {
      ind = new Individual(this.ruleBase, this.dataBase, this.w1, this.tuneCut);
      ind.randomValuesLat_RS();
      this.Population.add(ind);
    } 
    switch (this.ruleBase.typeInference) {
      case 2:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesExp(); 
        break;
      case 4:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesExp(); 
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesRDF(); 
        break;
      case 5:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesExp(); 
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesRDF(); 
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesSupport(); 
        break;
      case 6:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesExp(); 
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesSupport_6(); 
        break;
      case 7:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesSupport_7(); 
        break;
    } 
    this.best_fitness = 0.0D;
    this.nTrials = 0;
  }
  
  private void evaluate(int pos) {
    for (int i = pos; i < this.Population.size(); i++)
      ((Individual)this.Population.get(i)).evaluate(); 
    this.nTrials += this.Population.size() - pos;
  }
  
  private void selection() {
    int i;
    for (i = 0; i < this.pop_size; i++)
      this.selected[i] = i; 
    for (i = 0; i < this.pop_size; i++) {
      int random = Randomize.Randint(0, this.pop_size);
      int aux = this.selected[random];
      this.selected[random] = this.selected[i];
      this.selected[i] = aux;
    } 
  }
  
  private void xPC_BLX(double d, Individual son1, Individual son2) {
    son1.xPC_BLX(son2, d);
  }
  
  private void Hux(Individual son1, Individual son2) {
    son1.Hux(son2);
  }
  
  private void crossover() {
    for (int i = 0; i < this.pop_size; i += 2) {
      Individual dad = this.Population.get(this.selected[i]);
      Individual mom = this.Population.get(this.selected[i + 1]);
      double dist = dad.distHamming(mom, this.BITS_GEN);
      dist /= 2.0D;
      Individual son1 = dad.clone();
      Individual son2 = mom.clone();
      if (dist > this.L) {
        xPC_BLX(1.0D, son1, son2);
        Hux(son1, son2);
        son1.onNew();
        son2.onNew();
        this.Population.add(son1);
        this.Population.add(son2);
      } 
    } 
  }
  
  private void elitist() {
    Collections.sort(this.Population);
    while (this.Population.size() > this.pop_size)
      this.Population.remove(this.pop_size); 
    this.best_fitness = ((Individual)this.Population.get(0)).getFitness();
    this.evolution += "Accuracy / Fitness in the evaluacion " + this.nTrials + ": " + ((Individual)this.Population.get(0)).getAccuracy() + " / " + this.best_fitness + "\n";
    System.out.println("Accuracy / Fitness in the evaluacion " + this.nTrials + ": " + ((Individual)this.Population.get(0)).getAccuracy() + " / " + this.best_fitness);
  }
  
  public String getEvolution() {
    return this.evolution;
  }
  
  private boolean hasNew() {
    boolean state = false;
    for (int i = 0; i < this.pop_size; i++) {
      Individual ind = this.Population.get(i);
      if (ind.isNew()) {
        ind.offNew();
        state = true;
      } 
    } 
    return state;
  }
  
  private void restart() {
    this.w1 = 0.0D;
    Collections.sort(this.Population);
    Individual ind = ((Individual)this.Population.get(0)).clone();
    ind.setw1(this.w1);
    this.Population.clear();
    this.Population.add(ind);
    int i;
    for (i = 1; i < this.pop_size; i++) {
      ind = new Individual(this.ruleBase, this.dataBase, this.w1, this.tuneCut);
      ind.randomValuesLat_RS();
      this.Population.add(ind);
    } 
    switch (this.ruleBase.typeInference) {
      case 2:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesExp(); 
        break;
      case 4:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesExp(); 
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesRDF(); 
        break;
      case 5:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesExp(); 
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesRDF(); 
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesSupport(); 
        break;
      case 6:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesExp(); 
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesSupport_6(); 
        break;
      case 7:
        for (i = 1; i < this.pop_size; i++)
          ((Individual)this.Population.get(i)).randomValuesSupport_7(); 
        break;
    } 
    evaluate(0);
    this.L = this.Lini;
  }
  
  public RuleBase getBestRB() {
    Collections.sort(this.Population);
    RuleBase ruleBase = ((Individual)this.Population.get(0)).generateRB();
    return ruleBase;
  }
}
