package FARCHD;

import java.io.IOException;
import org.core.Files;
import org.core.Randomize;

public class Bull {
  myDataset train;
  
  myDataset val;
  
  myDataset test;
  
  String outputTr;
  
  String outputTst;
  
  String fileDB;
  
  String fileRB;
  
  String fileTime;
  
  String fileHora;
  
  String data;
  
  String fileRules;
  
  String fileEvo;
  
  String evolution;
  
  long rulesStage1;
  
  long rulesStage2;
  
  long rulesStage3;
  
  DataBase dataBase;
  
  RuleBase ruleBase;
  
  Apriori apriori;
  
  Population pop;
  
  long startTime;
  
  long totalTime;
  
  long startTimeApriori;
  
  long totalTimeApriori;
  
  long totalTimeConstruction;
  
  long startTimeEvTest;
  
  long totalTimeEvTest;
  
  int nLabels;
  
  int populationSize;
  
  int depth;
  
  int K;
  
  int maxTrials;
  
  int typeInference;
  
  int BITS_GEN;
  
  int typeQuality;
  
  int typeAggMatch;
  
  int typeRW;
  
  int tuneCut;
  
  int tipoFM;
  
  int opFM;
  
  int[] rC1;
  
  int[] rC2;
  
  int[] rC3;
  
  double minsup;
  
  double minconf;
  
  double alpha;
  
  double porApr;
  
  double porTest;
  
  private boolean somethingWrong = false;
  
  public Bull() {}
  
  public Bull(parseParameters parameters) {
    this.startTime = System.currentTimeMillis();
    this.outputTr = parameters.getTrainingOutputFile();
    this.outputTst = parameters.getTestOutputFile();
    this.fileDB = parameters.getOutputFile(0);
    this.fileRB = parameters.getOutputFile(1);
    this.data = parameters.getTrainingInputFile();
    this.fileTime = parameters.getOutputFile(1).substring(0, parameters.getOutputFile(1).lastIndexOf('.') - 2) + "Time.txt";
    this.fileHora = parameters.getOutputFile(1).substring(0, parameters.getOutputFile(1).lastIndexOf('.') - 2) + "Hora.txt";
    this.fileRules = parameters.getOutputFile(1).substring(0, parameters.getOutputFile(1).lastIndexOf('.') - 2) + "Rules.txt";
    this.fileEvo = parameters.getOutputFile(1).substring(0, parameters.getOutputFile(1).lastIndexOf('.') - 2) + "Evolution.txt";
    long seed = Long.parseLong(parameters.getParameter(0));
    Randomize.setSeed(seed);
    this.nLabels = Integer.parseInt(parameters.getParameter(1));
    this.minsup = Double.parseDouble(parameters.getParameter(2));
    this.minconf = Double.parseDouble(parameters.getParameter(3));
    this.depth = Integer.parseInt(parameters.getParameter(4));
    this.K = Integer.parseInt(parameters.getParameter(5));
    this.maxTrials = Integer.parseInt(parameters.getParameter(6));
    this.populationSize = Integer.parseInt(parameters.getParameter(7));
    if (this.populationSize % 2 > 0)
      this.populationSize++; 
    this.alpha = Double.parseDouble(parameters.getParameter(8));
    this.BITS_GEN = Integer.parseInt(parameters.getParameter(9));
    this.typeInference = Integer.parseInt(parameters.getParameter(10));
    this.typeQuality = Integer.parseInt(parameters.getParameter(11));
    this.typeAggMatch = Integer.parseInt(parameters.getParameter(12));
    this.typeRW = Integer.parseInt(parameters.getParameter(13));
    this.tuneCut = Integer.parseInt(parameters.getParameter(14));
    this.tuneCut = 0;
    this.tipoFM = Integer.parseInt(parameters.getParameter(15));
    this.opFM = Integer.parseInt(parameters.getParameter(16));
    this.train = new myDataset();
    this.val = new myDataset();
    this.test = new myDataset();
    try {
      System.out.println("\nReading the training set: " + parameters.getTrainingInputFile());
      this.train.readClassificationSet(parameters.getTrainingInputFile(), true);
      System.out.println("\nReading the validation set: " + parameters.getValidationInputFile());
      this.val.readClassificationSet(parameters.getValidationInputFile(), false);
      System.out.println("\nReading the test set: " + parameters.getTestInputFile());
      this.test.readClassificationSet(parameters.getTestInputFile(), false);
    } catch (IOException e) {
      System.err.println("There was a problem while reading the input data-sets: " + e);
      this.somethingWrong = true;
    } 
    this.somethingWrong = (this.somethingWrong || this.train.hasMissingAttributes());
  }
  
  public void execute() {
    if (this.somethingWrong) {
      System.err.println("An error was found, either the data-set has missing values.");
      System.err.println("Please remove the examples with missing data or apply a MV preprocessing.");
      System.err.println("Aborting the program");
    } else {
      this.rC1 = new int[2];
      this.rC2 = new int[2];
      this.rC3 = new int[2];
      for (int i = 0; i < 2; i++) {
        this.rC3[0] = 0;
        this.rC2[0] = 0;
        this.rC1[0] = 0;
        this.rC3[1] = 0;
        this.rC2[1] = 0;
        this.rC1[1] = 0;
      } 
      this.dataBase = new DataBase(this.nLabels, this.train, this.tuneCut, this.typeInference);
      this.ruleBase = new RuleBase(this.dataBase, this.train, this.K, this.typeInference, this.typeAggMatch, this.typeRW, this.tuneCut, this.tipoFM, this.opFM);
      this.apriori = new Apriori(this.ruleBase, this.dataBase, this.train, this.minsup, this.minconf, this.depth, this.typeQuality, this.typeAggMatch, this.tuneCut, this.tipoFM, this.opFM);
      this.startTimeApriori = System.currentTimeMillis();
      this.rC1 = this.apriori.generateRB();
      this.totalTimeApriori = System.currentTimeMillis() - this.startTimeApriori;
      this.totalTimeApriori /= 1000L;
      long seg = this.totalTimeApriori % 60L;
      this.totalTimeApriori /= 60L;
      long min = this.totalTimeApriori % 60L;
      long hor = this.totalTimeApriori / 60L;
      String stringApriori = "";
      stringApriori = (hor < 10L) ? (stringApriori + "0" + hor + ":") : (stringApriori + hor + ":");
      stringApriori = (min < 10L) ? (stringApriori + "0" + min + ":") : (stringApriori + min + ":");
      stringApriori = (seg < 10L) ? (stringApriori + "0" + seg) : (stringApriori + seg);
      System.out.println("Construcion time of Apriori: " + stringApriori);
      this.rulesStage1 = this.apriori.getRulesStage1();
      this.rulesStage2 = this.ruleBase.size();
      this.rC2 = this.ruleBase.getRulesPerClass();
      System.out.println("Number of rules after Apriori: " + this.ruleBase.size());
      System.out.println("Starting the evolutionary process");
      this.pop = new Population(this.train, this.dataBase, this.ruleBase, this.populationSize, this.BITS_GEN, this.maxTrials, this.alpha, this.tuneCut);
      this.pop.Generation();
      System.out.println("Building classifier");
      this.ruleBase = this.pop.getBestRB();
      this.totalTimeConstruction = System.currentTimeMillis() - this.startTimeApriori;
      this.ruleBase.evaluateDS(this.train);
      System.out.println("Result in train: " + this.ruleBase.getAccuracyEv());
      this.ruleBase.evaluateDS(this.test);
      System.out.println("Result in test: " + this.ruleBase.getAccuracyEv());
      this.rulesStage3 = this.ruleBase.size();
      this.rC3 = this.ruleBase.getRulesPerClass();
      this.evolution = this.pop.getEvolution();
      this.dataBase.saveFile(this.fileDB);
      this.ruleBase.saveFile(this.fileRB);
      doOutput(this.val, this.outputTr);
      this.startTimeEvTest = System.currentTimeMillis();
      doOutput(this.test, this.outputTst);
      this.totalTimeEvTest = System.currentTimeMillis() - this.startTimeEvTest;
      this.totalTime = System.currentTimeMillis() - this.startTime;
      this.porApr = (this.totalTime - this.totalTimeEvTest) / this.totalTime * 100.0D;
      this.porTest = this.totalTimeEvTest / this.totalTime * 100.0D;
      writeTime();
      writeRules();
      writeEvo();
      System.out.println("Algorithm Finished");
    } 
  }
  
  public void writeEvo() {
    this.evolution += "\n\n";
    Files.writeFile(this.fileEvo, this.evolution);
  }
  
  public void writeRules() {
    String stringOut = "";
    stringOut = "Rules per stage:\n" + this.rulesStage1 + " " + this.rulesStage2 + " " + this.rulesStage3 + "\n";
    stringOut = stringOut + "Rules per class in stage 1:\n" + this.rC1[0] + " " + this.rC1[1] + "\n";
    stringOut = stringOut + "Rules per class in stage 2:\n" + this.rC2[0] + " " + this.rC2[1] + "\n";
    stringOut = stringOut + "Rules per class in stage 3:\n" + this.rC3[0] + " " + this.rC3[1] + "\n";
    Files.writeFile(this.fileRules, stringOut);
  }
  
  public void writeTime() {
    String stringOut = "";
    long tT = this.totalTime % 1000L;
    long tC = this.totalTimeConstruction % 1000L;
    long tE = this.totalTimeEvTest % 1000L;
    stringOut = "" + (this.totalTime / 1000L) + ":" + tT + " " + (this.totalTimeConstruction / 1000L) + ":" + tC + " " + (this.totalTimeEvTest / 1000L) + ":" + tE + " " + this.data + "\n";
    Files.writeFile(this.fileTime, stringOut);
    this.totalTime /= 1000L;
    long seg = this.totalTime % 60L;
    this.totalTime /= 60L;
    long min = this.totalTime % 60L;
    long hor = this.totalTime / 60L;
    stringOut = "";
    stringOut = (hor < 10L) ? (stringOut + "0" + hor + ":") : (stringOut + hor + ":");
    stringOut = (min < 10L) ? (stringOut + "0" + min + ":") : (stringOut + min + ":");
    stringOut = (seg < 10L) ? (stringOut + "0" + seg) : (stringOut + seg);
    stringOut = stringOut + "  " + this.data + "\n";
    Files.writeFile(this.fileHora, stringOut);
  }
  
  private void doOutput(myDataset dataset, String filename) {
    String output = "";
    output = dataset.copyHeader();
    for (int i = 0; i < dataset.getnData(); i++)
      output = output + dataset.getOutputAsString(i) + " " + classificationOutput(dataset.getExample(i)) + "\n"; 
    Files.writeFile(filename, output);
  }
  
  private String classificationOutput(double[] example) {
    String output = "?";
    int clas = this.ruleBase.FRM(example);
    if (clas >= 0)
      output = this.train.getOutputValue(clas); 
    return output;
  }
}
