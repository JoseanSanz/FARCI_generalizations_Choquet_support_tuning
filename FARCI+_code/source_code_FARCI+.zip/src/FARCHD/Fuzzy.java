package FARCHD;

public class Fuzzy {
  double x0;
  
  double x1;
  
  double x3;
  
  double y;
  
  String name;
  
  public double Fuzzifica(double X) {
    if (X == this.x1)
      return 1.0D; 
    if (X <= this.x0 || X >= this.x3)
      return 0.0D; 
    if (X < this.x1)
      return (X - this.x0) * this.y / (this.x1 - this.x0); 
    if (X > this.x1)
      return (this.x3 - X) * this.y / (this.x3 - this.x1); 
    return this.y;
  }
  
  public Fuzzy clone() {
    Fuzzy d = new Fuzzy();
    d.x0 = this.x0;
    d.x1 = this.x1;
    d.x3 = this.x3;
    d.y = this.y;
    d.name = new String(this.name);
    return d;
  }
  
  public String getName() {
    return this.name;
  }
}
