package FARCHD;

import org.core.Files;

public class DataBase {
  int n_variables;
  
  int partitions;
  
  int tuneCut;
  
  int n_classes;
  
  int typeInference;
  
  int[] nLabels;
  
  boolean[] varReal;
  
  Fuzzy[][] dataBase;
  
  Fuzzy[][] dataBaseIni;
  
  double[] exp;
  
  String[] names;
  
  double[] cut;
  
  double[] aut1;
  
  double[] aut2;
  
  double umbral;
  
  public DataBase() {}
  
  public DataBase(int nLabels, myDataset train, int tuneCutt, int typeInference) {
    double[][] ranks = train.returnRanks();
    this.n_variables = train.getnInputs();
    this.names = (String[])train.names().clone();
    this.nLabels = new int[this.n_variables];
    this.varReal = new boolean[this.n_variables];
    this.dataBase = new Fuzzy[this.n_variables][];
    this.dataBaseIni = new Fuzzy[this.n_variables][];
    this.n_classes = train.getnClasses();
    this.umbral = 0.92D;
    this.exp = new double[this.n_classes];
    this.aut1 = new double[this.n_variables];
    this.aut2 = new double[this.n_variables];
    int i;
    for (i = 0; i < this.n_classes; i++)
      this.exp[i] = 1.0D; 
    this.tuneCut = this.tuneCut;
    this.typeInference = typeInference;
    this.cut = new double[2];
    this.cut[1] = 0.0D;
    this.cut[0] = 0.0D;
    for (i = 0; i < this.n_variables; i++) {
      double rank = Math.abs(ranks[i][1] - ranks[i][0]);
      this.varReal[i] = false;
      if (train.isNominal(i)) {
        this.nLabels[i] = (int)rank + 1;
      } else if (train.isInteger(i) && rank + 1.0D <= nLabels) {
        this.nLabels[i] = (int)rank + 1;
      } else {
        this.nLabels[i] = nLabels;
        this.varReal[i] = true;
      } 
      this.aut1[i] = 1.0D;
      this.aut2[i] = 1.0D;
      this.dataBase[i] = new Fuzzy[this.nLabels[i]];
      this.dataBaseIni[i] = new Fuzzy[this.nLabels[i]];
      double mark = rank / ((double)this.nLabels[i] - 1.0);
      for (int j = 0; j < this.nLabels[i]; j++) {
        this.dataBase[i][j] = new Fuzzy();
        this.dataBaseIni[i][j] = new Fuzzy();
        double value = ranks[i][0] + mark * (j - 1);
        (this.dataBaseIni[i][j]).x0 = (this.dataBase[i][j]).x0 = setValue(value, ranks[i][0], ranks[i][1]);
        value = ranks[i][0] + mark * j;
        (this.dataBaseIni[i][j]).x1 = (this.dataBase[i][j]).x1 = setValue(value, ranks[i][0], ranks[i][1]);
        value = ranks[i][0] + mark * (j + 1);
        (this.dataBaseIni[i][j]).x3 = (this.dataBase[i][j]).x3 = setValue(value, ranks[i][0], ranks[i][1]);
        (this.dataBase[i][j]).y = 1.0D;
        (this.dataBaseIni[i][j]).y = 1.0D;
        (this.dataBase[i][j]).name = new String("L_" + j + "(" + this.nLabels[i] + ")");
        (this.dataBaseIni[i][j]).name = new String("L_" + j + "(" + this.nLabels[i] + ")");
      } 
    } 
  }
  
  private double setValue(double val, double min, double tope) {
    if (val > min - 1.0E-4D && val < min + 1.0E-4D)
      return min; 
    if (val > tope - 1.0E-4D && val < tope + 1.0E-4D)
      return tope; 
    return val;
  }
  
  public void decode(double[] gene) {
    int pos = 0;
    int i;
    for (i = 0; i < this.n_variables; i++) {
      if (this.varReal[i]) {
        int j = 0;
        while (j < this.nLabels[i]) {
            double displacement = (j == 0) ? ((gene[pos] - 0.5D) * ((this.dataBaseIni[i][j + 1]).x1 - (this.dataBaseIni[i][j]).x1)) : ((j == this.nLabels[i] - 1) ? ((gene[pos] - 0.5D) * ((this.dataBaseIni[i][j]).x1 - (this.dataBaseIni[i][j - 1]).x1)) : ((gene[pos] - 0.5D < 0.0D) ? ((gene[pos] - 0.5D) * ((this.dataBaseIni[i][j]).x1 - (this.dataBaseIni[i][j - 1]).x1)) : ((gene[pos] - 0.5D) * ((this.dataBaseIni[i][j + 1]).x1 - (this.dataBaseIni[i][j]).x1))));
            this.dataBase[i][j].x0 = this.dataBaseIni[i][j].x0 + displacement;
            this.dataBase[i][j].x1 = this.dataBaseIni[i][j].x1 + displacement;
            this.dataBase[i][j].x3 = this.dataBaseIni[i][j].x3 + displacement;
            j++;
            pos++;
        } 
      } 
    }
    if (this.typeInference == 2 || this.typeInference == 4 || this.typeInference == 5 || this.typeInference == 6) {
      int j = 0;
      for (i = pos; i < pos + this.n_classes; i++) {
        double aux1 = gene[i];
        if (aux1 > 1.0D)
          aux1 = 1.0D / (2.0D - aux1); 
        this.exp[j] = aux1;
        j++;
      } 
      pos += this.n_classes;
    } 
    if (this.typeInference == 4 || this.typeInference == 5) {
      int j = 0;
      for (i = pos; i < pos + this.n_variables; i++) {
        double aux1 = gene[i];
        if (aux1 <= 0.5D) {
          this.aut1[j] = 2.0D * aux1;
        } else {
          aux1 = 4.42859D / (2.0D * this.umbral - 1.0D) * (aux1 - (0.5D + this.umbral) / 2.0D);
          this.aut1[j] = Math.tan(aux1) + 3.0D;
        } 
        j++;
      } 
      j = 0;
      for (i = pos += this.n_variables; i < pos + this.n_variables; i++) {
        double aux2 = gene[i];
        if (aux2 <= 0.5D) {
          this.aut2[j] = 2.0D * aux2;
        } else {
          aux2 = 4.42859D / (2.0D * this.umbral - 1.0D) * (aux2 - (0.5D + this.umbral) / 2.0D);
          this.aut2[j] = Math.tan(aux2) + 3.0D;
        } 
        j++;
      } 
      pos += this.n_variables;
    } 
    if (this.typeInference == 5 || this.typeInference == 6 || this.typeInference == 7)
      for (i = 0; i < this.n_variables; i++) {
        if (this.varReal[i])
          for (int k = 0; k < this.nLabels[i]; k++, pos++) {
            double dispSup = (gene[pos] - 0.5D) * ((this.dataBaseIni[i][k]).x3 - (this.dataBaseIni[i][k]).x0);
            (this.dataBase[i][k]).x0 -= (dispSup / 2.0);
            (this.dataBase[i][k]).x3 += (dispSup / 2.0);
          }  
      }  
    if (this.tuneCut == 1) {
      this.cut[0] = gene[pos];
      this.cut[1] = gene[pos + 1];
    } 
  }
  
  public int numVariables() {
    return this.n_variables;
  }
  
  public int getnLabelsReal() {
    int count = 0;
    for (int i = 0; i < this.n_variables; i++) {
      if (this.varReal[i])
        count += this.nLabels[i]; 
    } 
    return count;
  }
  
  public int numLabels(int variable) {
    return this.nLabels[variable];
  }
  
  public int[] getnLabels() {
    return this.nLabels;
  }
  
  public double matching(int variable, int label, double value) {
    if (variable < 0 || label < 0)
      return 1.0D; 
    return this.dataBase[variable][label].Fuzzifica(value);
  }
  
  public String print_triangle(int var, int label) {
    String cadena = new String("");
    Fuzzy d = this.dataBase[var][label];
    cadena = d.name + ": \t" + d.x0 + "\t" + d.x1 + "\t" + d.x3 + "\n";
    return cadena;
  }
  
  public String print(int var, int label) {
    return this.dataBase[var][label].getName();
  }
  
  public String printString() {
    String string = new String("@Using Triangular Membership Functions as antecedent fuzzy sets");
    int i;
    for (i = 0; i < this.n_variables; i++) {
      string = string + "\n\n@Number of Labels in Variable " + (i + 1) + ": " + this.nLabels[i];
      string = string + "\n" + this.names[i] + ":\n";
      for (int j = 0; j < this.nLabels[i]; j++)
        string = string + (this.dataBase[i][j]).name + ": (" + (this.dataBase[i][j]).x0 + "," + (this.dataBase[i][j]).x1 + "," + (this.dataBase[i][j]).x3 + ")\n"; 
    } 
    string = string + "\n\nValues of the cut: " + this.cut[0] + ", " + this.cut[1] + "\n";
    string = string + "\n\n@Values of the exponents of the classes:\n";
    for (i = 0; i < this.n_classes; i++)
      string = string + "Class " + (i + 1) + ": " + this.exp[i] + "\n"; 
    string = string + "\n\n@Values of the automorphism 1:\n";
    for (i = 0; i < this.n_variables; i++)
      string = string + "Autorphism 1 in variable " + (i + 1) + ": " + this.aut1[i] + "\n"; 
    string = string + "\n\n@Values of the automorphism 2:\n";
    for (i = 0; i < this.n_variables; i++)
      string = string + "Autorphism 2 in variable " + (i + 1) + ": " + this.aut2[i] + "\n"; 
    return string;
  }
  
  public void saveFile(String filename) {
    String stringOut = new String("");
    stringOut = printString();
    Files.writeFile(filename, stringOut);
  }
}
