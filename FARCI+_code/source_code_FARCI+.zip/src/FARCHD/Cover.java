package FARCHD;

public class Cover {
  int pos;
  
  public Cover(int pos) {
    this.pos = pos;
  }
  
  public Cover clone() {
    return new Cover(this.pos);
  }
  
  public int getPos() {
    return this.pos;
  }
}
