package FARCHD;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.TreeMap;
import org.core.Files;

public class RuleBase {
  ArrayList<Rule> ruleBase;
  
  DataBase dataBase;
  
  myDataset train;
  
  int n_variables;
  
  int K;
  
  int nUncover;
  
  int typeInference;
  
  int defaultRule;
  
  int typeRW;
  
  int typeAggMatch;
  
  int tuneCut;
  
  int tipoFM;
  
  int opFM;
  
  int[] nUncoverClas;
  
  int[] Ks;
  
  int[] opFMs;
  
  int[] typeRDFs;
  
  double fitness;
  
  double fitnessEv;
  
  double rec0;
  
  double rec1;
  
  double rec0Ev;
  
  double rec1Ev;
  
  double[] Ws;
  
  public boolean BETTER(int a, int b) {
    return (a > b);
  }
  
  public RuleBase() {}
  
  public RuleBase(DataBase dataBase, myDataset train, int K, int typeInference, int typeAggMatch, int typeRW, int tuneCut, int tipoFM, int opFM) {
    this.ruleBase = new ArrayList<>();
    this.dataBase = dataBase;
    this.train = train;
    this.n_variables = dataBase.numVariables();
    this.fitness = 0.0D;
    this.rec0 = 0.0D;
    this.rec1 = 0.0D;
    this.rec0Ev = 0.0D;
    this.rec1Ev = 0.0D;
    this.fitnessEv = 0.0D;
    this.K = K;
    this.typeInference = typeInference;
    this.typeAggMatch = typeAggMatch;
    this.typeRW = typeRW;
    this.tuneCut = tuneCut;
    this.defaultRule = -1;
    this.nUncover = 0;
    this.nUncoverClas = new int[this.train.getnClasses()];
    this.tipoFM = tipoFM;
    this.opFM = opFM;
    this.opFMs = new int[6];
    this.typeRDFs = new int[6];
    for (int i = 0; i < 6; i++) {
      this.typeRDFs[i] = -1;
      this.opFMs[i] = -1;
    } 
    int classes = this.train.getnClasses();
    this.Ks = new int[classes];
    for (int j = 0; j < classes; j++)
      this.Ks[j] = (int)(this.K / this.train.frecuentClass(j)); 
    this.Ws = new double[classes];
    if (this.train.frecuentClass(0) > this.train.frecuentClass(1)) {
      double aux = this.train.frecuentClass(1) / this.train.frecuentClass(0);
      this.Ws[0] = aux * 0.5D + 0.5D;
      this.Ws[1] = 1.0D;
    } else {
      double aux = this.train.frecuentClass(0) / this.train.frecuentClass(1);
      this.Ws[1] = aux * 0.5D + 0.5D;
      this.Ws[0] = 1.0D;
    } 
  }
  
  public RuleBase(DataBase dataBase, myDataset train, int K, int typeInference, int typeAggMatch, int typeRW, int tuneCut, int tipoFM, int opFM, int clase) {
    this.ruleBase = new ArrayList<>();
    this.dataBase = dataBase;
    this.train = train;
    this.n_variables = dataBase.numVariables();
    this.fitness = 0.0D;
    this.rec0 = 0.0D;
    this.rec1 = 0.0D;
    this.rec0Ev = 0.0D;
    this.rec1Ev = 0.0D;
    this.fitnessEv = 0.0D;
    this.K = K;
    this.typeInference = typeInference;
    this.typeAggMatch = typeAggMatch;
    this.typeRW = typeRW;
    this.tuneCut = tuneCut;
    this.defaultRule = -1;
    this.nUncover = 0;
    this.nUncoverClas = new int[this.train.getnClasses()];
    this.tipoFM = tipoFM;
    this.opFM = opFM;
    this.opFMs = new int[6];
    this.typeRDFs = new int[6];
    for (int i = 0; i < 6; i++) {
      this.typeRDFs[i] = -1;
      this.opFMs[i] = -1;
    } 
    int classes = this.train.getnClasses();
    this.Ks = new int[classes];
    this.Ws = new double[classes];
    if (this.train.frecuentClass(0) > this.train.frecuentClass(1)) {
      double aux = this.train.frecuentClass(1) / this.train.frecuentClass(0);
      if (clase == 0) {
        this.Ks[0] = this.K;
        this.Ks[1] = this.K;
        this.Ws[0] = 1.0D;
        this.Ws[1] = 1.0D;
      } else {
        for (int j = 0; j < classes; j++)
          this.Ks[j] = (int)(this.K / this.train.frecuentClass(j)); 
        this.Ws[0] = aux * 0.5D + 0.5D;
        this.Ws[1] = 1.0D;
      } 
    } else {
      double aux = this.train.frecuentClass(0) / this.train.frecuentClass(1);
      if (clase == 1) {
        this.Ks[1] = this.K;
        this.Ks[0] = this.K;
        this.Ws[1] = 1.0D;
        this.Ws[0] = 1.0D;
      } else {
        for (int j = 0; j < classes; j++)
          this.Ks[j] = (int)(this.K / this.train.frecuentClass(j)); 
        this.Ws[1] = aux * 0.5D + 0.5D;
        this.Ws[0] = 1.0D;
      } 
    } 
  }
  
  public RuleBase clone() {
    RuleBase br = new RuleBase();
    br.ruleBase = new ArrayList<>();
    int i;
    for (i = 0; i < this.ruleBase.size(); i++)
      br.ruleBase.add(((Rule)this.ruleBase.get(i)).clone()); 
    br.dataBase = this.dataBase;
    br.train = this.train;
    br.n_variables = this.n_variables;
    br.fitness = this.fitness;
    br.rec0 = this.rec0;
    br.rec1 = this.rec1;
    br.rec0Ev = this.rec0Ev;
    br.rec1Ev = this.rec1Ev;
    br.fitnessEv = this.fitnessEv;
    br.K = this.K;
    br.typeInference = this.typeInference;
    br.typeAggMatch = this.typeAggMatch;
    br.typeRW = this.typeRW;
    br.tuneCut = this.tuneCut;
    br.defaultRule = this.defaultRule;
    br.nUncover = this.nUncover;
    br.nUncoverClas = new int[this.train.getnClasses()];
    br.tipoFM = this.tipoFM;
    br.opFM = this.opFM;
    br.opFMs = this.opFMs;
    br.typeRDFs = this.typeRDFs;
    for (i = 0; i < 6; i++) {
      br.typeRDFs[i] = this.opFMs[i];
      br.opFMs[i] = this.opFMs[i];
    } 
    br.Ks = new int[this.train.getnClasses()];
    br.Ws = new double[this.train.getnClasses()];
    for (i = 0; i < this.train.getnClasses(); i++) {
      br.nUncoverClas[i] = this.nUncoverClas[i];
      br.Ks[i] = this.Ks[i];
      br.Ws[i] = this.Ws[i];
    } 
    return br;
  }
  
  public void add(Rule rule) {
    this.ruleBase.add(rule);
  }
  
  public void add(RuleBase ruleBase) {
    for (int i = 0; i < ruleBase.size(); i++)
      this.ruleBase.add(ruleBase.get(i).clone()); 
  }
  
  public void add(Itemset itemset) {
    int[] antecedent = new int[this.n_variables];
    int i;
    for (i = 0; i < this.n_variables; i++)
      antecedent[i] = -1; 
    for (i = 0; i < itemset.size(); i++) {
      Item item = itemset.get(i);
      antecedent[item.getVariable()] = item.getValue();
    } 
    Rule r = new Rule(this.dataBase);
    r.asignaAntecedente(antecedent);
    r.setConsequent(itemset.getClas());
    r.setConfidence(itemset.getSupportClass() / itemset.getSupport());
    r.setSupport(itemset.getSupportClass());
    this.ruleBase.add(r);
  }
  
  public void recomputeQualityMeasures() {
    for (int i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      double sup = 0.0D;
      double supC = 0.0D;
      for (int j = 0; j < this.train.size(); j++) {
        double degree = r.matchingAnt(this.train.getExample(j), this.typeAggMatch, this.tuneCut);
        sup += degree;
        if (this.train.getOutputAsInteger(j) == r.getClas())
          supC += degree; 
      } 
      if (sup == 0.0D) {
        r.setConfidence(0.0D);
      } else {
        r.setConfidence(supC / sup);
      } 
      r.setSupport(supC / this.train.getnData());
      r.setSupportAntecedent(sup / this.train.getnData());
      double supR = supC / this.train.getnData();
      double supAnt = sup / this.train.getnData();
      double supCons = this.train.frecuentClass(r.getClas());
      double lift = (supAnt == 0.0D) ? 0.0D : supR / (supAnt * supCons);
      r.setLift(lift);
    } 
  }
  
  public Rule get(int pos) {
    return this.ruleBase.get(pos);
  }
  
  public int size() {
    return this.ruleBase.size();
  }
  
  public void set_opFM(int opFM) {
    this.opFM = opFM;
  }
  
  public void sort() {
    Collections.sort(this.ruleBase);
  }
  
  public Rule remove(int pos) {
    return this.ruleBase.remove(pos);
  }
  
  public void clear() {
    this.ruleBase.clear();
    this.fitness = 0.0D;
  }
  
  public int getTypeInference() {
    return this.typeInference;
  }
  
  public int getTypeAggMatch() {
    return this.typeAggMatch;
  }
  
  public int getTypeRW() {
    return this.typeRW;
  }
  
  public double getAccuracy() {
    return this.fitness;
  }
  
  public double getAccuracyEv() {
    return this.fitnessEv;
  }
  
  public double getRec0() {
    return this.rec0;
  }
  
  public double getRec1() {
    return this.rec1;
  }
  
  public double getRec0Ev() {
    return this.rec0Ev;
  }
  
  public double getRec1Ev() {
    return this.rec1Ev;
  }
  
  public void setDefaultRule() {
    int bestRule = 0;
    for (int i = 1; i < this.train.getnClasses(); i++) {
      if (this.train.numberInstances(bestRule) < this.train.numberInstances(i))
        bestRule = i; 
    } 
    this.defaultRule = bestRule;
  }
  
  public boolean hasUncover() {
    return (this.nUncover > 0);
  }
  
  public int getUncover() {
    return this.nUncover;
  }
  
  public int getK() {
    return this.K;
  }
  
  public void evaluate() {
    int[] matriz = new int[4];
    int tp = 0;
    int tn = 0;
    int fp = 0;
    int fn = 0;
    recomputeQualityMeasures();
    int nHits = 0;
    this.nUncover = 0;
    int j;
    for (j = 0; j < this.train.getnClasses(); j++)
      this.nUncoverClas[j] = 0; 
    for (j = 0; j < this.train.size(); j++) {
      int prediction = FRM(this.train.getExample(j));
      if (this.train.getOutputAsInteger(j) == prediction)
        nHits++; 
      matriz = obtener_matriz_confusion(this.train.getOutputAsInteger(j), prediction);
      tp += matriz[0];
      fp += matriz[1];
      fn += matriz[2];
      tn += matriz[3];
      if (prediction < 0) {
        this.nUncover++;
        int n = this.train.getOutputAsInteger(j);
        this.nUncoverClas[n] = this.nUncoverClas[n] + 1;
      } 
    } 
    this.fitness = compute_f1_score(tp, fp, fn, tn);
  }
  
  public void evaluateDS(myDataset DS) {
    int[] matriz = new int[4];
    int tp = 0;
    int tn = 0;
    int fp = 0;
    int fn = 0;
    recomputeQualityMeasures();
    int nHits = 0;
    this.nUncover = 0;
    int j;
    for (j = 0; j < DS.getnClasses(); j++)
      this.nUncoverClas[j] = 0; 
    for (j = 0; j < DS.size(); j++) {
      int prediction = FRM(DS.getExample(j));
      if (DS.getOutputAsInteger(j) == prediction)
        nHits++; 
      matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
      tp += matriz[0];
      fp += matriz[1];
      fn += matriz[2];
      tn += matriz[3];
      if (prediction < 0) {
        this.nUncover++;
        int n = DS.getOutputAsInteger(j);
        this.nUncoverClas[n] = this.nUncoverClas[n] + 1;
      } 
    } 
    this.fitnessEv = compute_f1_score(tp, fp, fn, tn);
  }
  
  public void evaluateDS_stats(myDataset DS, int typeInference) {
    int[] salidaFRM = new int[2];
    int[] matriz = new int[4];
    int tp5 = 0;
    int tp4 = 0;
    int tp3 = 0;
    int tp2 = 0;
    int tp1 = 0;
    int tp0 = 0;
    int tp = 0;
    int tn5 = 0;
    int tn4 = 0;
    int tn3 = 0;
    int tn2 = 0;
    int tn1 = 0;
    int tn0 = 0;
    int tn = 0;
    int fp5 = 0;
    int fp4 = 0;
    int fp3 = 0;
    int fp2 = 0;
    int fp1 = 0;
    int fp0 = 0;
    int fp = 0;
    int fn5 = 0;
    int fn4 = 0;
    int fn3 = 0;
    int fn2 = 0;
    int fn1 = 0;
    int fn0 = 0;
    int fn = 0;
    double cont5 = 0.0D;
    double cont4 = 0.0D;
    double cont3 = 0.0D;
    double cont2 = 0.0D;
    double cont1 = 0.0D;
    double cont0 = 0.0D;
    double cont = 0.0D;
    double hints5 = 0.0D;
    double hints4 = 0.0D;
    double hints3 = 0.0D;
    double hints2 = 0.0D;
    double hints1 = 0.0D;
    double hints0 = 0.0D;
    recomputeQualityMeasures();
    int nHits = 0;
    this.nUncover = 0;
    int j;
    for (j = 0; j < DS.getnClasses(); j++)
      this.nUncoverClas[j] = 0; 
    for (j = 0; j < DS.size(); j++) {
      salidaFRM = FRM_stats(DS.getExample(j), typeInference);
      int prediction = salidaFRM[0];
      int caso = salidaFRM[1];
      if (caso < 0)
        cont++; 
      if (DS.getOutputAsInteger(j) == prediction)
        nHits++; 
      if (caso == 0) {
        cont0++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints0++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp0 += matriz[0];
        fp0 += matriz[1];
        fn0 += matriz[2];
        tn0 += matriz[3];
      } else if (caso == 1) {
        cont1++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints1++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp1 += matriz[0];
        fp1 += matriz[1];
        fn1 += matriz[2];
        tn1 += matriz[3];
      } else if (caso == 2) {
        cont2++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints2++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp2 += matriz[0];
        fp2 += matriz[1];
        fn2 += matriz[2];
        tn2 += matriz[3];
      } else if (caso == 3) {
        cont3++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints3++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp3 += matriz[0];
        fp3 += matriz[1];
        fn3 += matriz[2];
        tn3 += matriz[3];
      } else if (caso == 4) {
        cont4++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints4++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp4 += matriz[0];
        fp4 += matriz[1];
        fn4 += matriz[2];
        tn4 += matriz[3];
      } else if (caso == 5) {
        cont5++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints5++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp5 += matriz[0];
        fp5 += matriz[1];
        fn5 += matriz[2];
        tn5 += matriz[3];
      } 
      matriz = obtener_matriz_confusion(this.train.getOutputAsInteger(j), prediction);
      tp += matriz[0];
      fp += matriz[1];
      fn += matriz[2];
      tn += matriz[3];
      if (prediction < 0) {
        this.nUncover++;
        int n = DS.getOutputAsInteger(j);
        this.nUncoverClas[n] = this.nUncoverClas[n] + 1;
      } 
    } 
    this.fitnessEv = compute_f1_score(tp, fp, fn, tn);
    System.out.println("Porcentaje de acierto en cada caso:");
    System.out.println("Caso 0: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp0, fp0, fn0, tn0)) }) + " numero de ejemplos: " + cont0);
    System.out.println("Caso 1: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp1, fp1, fn1, tn1)) }) + " numero de ejemplos: " + cont1);
    System.out.println("Caso 2: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp2, fp2, fn2, tn2)) }) + " numero de ejemplos: " + cont2);
    System.out.println("Caso 3: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp3, fp3, fn3, tn3)) }) + " numero de ejemplos: " + cont3);
    System.out.println("Caso 4: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp4, fp4, fn4, tn4)) }) + " numero de ejemplos: " + cont4);
    System.out.println("Caso 5: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp5, fp5, fn5, tn5)) }) + " numero de ejemplos: " + cont5);
    System.out.println("Porcentaje de ejemplos susceptibles de cambios: " + String.format("%.3f", new Object[] { Double.valueOf((cont0 + cont1 + cont2 + cont3 + cont4 + cont5) / DS.size()) }));
  }
  
  public void evaluateDS_ratio_fired_rules_stats(myDataset DS, int typeInference) {
    int[] salidaFRM = new int[3];
    int[] matriz = new int[4];
    int tp = 0;
    int tn = 0;
    int fp = 0;
    int fn = 0;
    int numRulesLarger = 0;
    int numRulesLess = 0;
    int numCases = 0;
    double cont = 0.0D;
    recomputeQualityMeasures();
    int nHits = 0;
    this.nUncover = 0;
    int j;
    for (j = 0; j < DS.getnClasses(); j++)
      this.nUncoverClas[j] = 0; 
    for (j = 0; j < DS.size(); j++) {
      salidaFRM = FRM_fired_rules_stats(DS.getExample(j), typeInference);
      int prediction = salidaFRM[0];
      if (salidaFRM[2] > 0) {
        numRulesLarger += salidaFRM[1];
        numRulesLess += salidaFRM[2];
        numCases++;
      } 
      if (DS.getOutputAsInteger(j) == prediction)
        nHits++; 
      matriz = obtener_matriz_confusion(this.train.getOutputAsInteger(j), prediction);
      tp += matriz[0];
      fp += matriz[1];
      fn += matriz[2];
      tn += matriz[3];
      if (prediction < 0) {
        this.nUncover++;
        int n = DS.getOutputAsInteger(j);
        this.nUncoverClas[n] = this.nUncoverClas[n] + 1;
      } 
    } 
    this.fitnessEv = compute_f1_score(tp, fp, fn, tn);
    if (numCases > 0) {
      System.out.println("Ratio de reglas disparadas por clase: " + String.format("%.3f", new Object[] { Float.valueOf(numRulesLarger / numRulesLess) }) + ", en porcentaje de casos: " + String.format("%.3f", new Object[] { Double.valueOf((numCases / DS.size()) * 100.0D) }));
    } else {
      System.out.println("Ratio de reglas disparadas por clase: 0.000, en porcentaje de casos: " + String.format("%.3f", new Object[] { Double.valueOf((numCases / DS.size()) * 100.0D) }));
    } 
  }
  
  public double[] evaluateDS_stats_learn(myDataset DS, int typeInference) {
    int[] salidaFRM = new int[2];
    int[] matriz = new int[4];
    int tp5 = 0;
    int tp4 = 0;
    int tp3 = 0;
    int tp2 = 0;
    int tp1 = 0;
    int tp0 = 0;
    int tp = 0;
    int tn5 = 0;
    int tn4 = 0;
    int tn3 = 0;
    int tn2 = 0;
    int tn1 = 0;
    int tn0 = 0;
    int tn = 0;
    int fp5 = 0;
    int fp4 = 0;
    int fp3 = 0;
    int fp2 = 0;
    int fp1 = 0;
    int fp0 = 0;
    int fp = 0;
    int fn5 = 0;
    int fn4 = 0;
    int fn3 = 0;
    int fn2 = 0;
    int fn1 = 0;
    int fn0 = 0;
    int fn = 0;
    double cont5 = 0.0D;
    double cont4 = 0.0D;
    double cont3 = 0.0D;
    double cont2 = 0.0D;
    double cont1 = 0.0D;
    double cont0 = 0.0D;
    double cont = 0.0D;
    double hints5 = 0.0D;
    double hints4 = 0.0D;
    double hints3 = 0.0D;
    double hints2 = 0.0D;
    double hints1 = 0.0D;
    double hints0 = 0.0D;
    recomputeQualityMeasures();
    int nHits = 0;
    this.nUncover = 0;
    int j;
    for (j = 0; j < DS.getnClasses(); j++)
      this.nUncoverClas[j] = 0; 
    for (j = 0; j < DS.size(); j++) {
      salidaFRM = FRM_stats(DS.getExample(j), typeInference);
      int prediction = salidaFRM[0];
      int caso = salidaFRM[1];
      if (caso < 0)
        cont++; 
      if (DS.getOutputAsInteger(j) == prediction)
        nHits++; 
      if (caso == 0) {
        cont0++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints0++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp0 += matriz[0];
        fp0 += matriz[1];
        fn0 += matriz[2];
        tn0 += matriz[3];
      } else if (caso == 1) {
        cont1++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints1++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp1 += matriz[0];
        fp1 += matriz[1];
        fn1 += matriz[2];
        tn1 += matriz[3];
      } else if (caso == 2) {
        cont2++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints2++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp2 += matriz[0];
        fp2 += matriz[1];
        fn2 += matriz[2];
        tn2 += matriz[3];
      } else if (caso == 3) {
        cont3++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints3++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp3 += matriz[0];
        fp3 += matriz[1];
        fn3 += matriz[2];
        tn3 += matriz[3];
      } else if (caso == 4) {
        cont4++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints4++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp4 += matriz[0];
        fp4 += matriz[1];
        fn4 += matriz[2];
        tn4 += matriz[3];
      } else if (caso == 5) {
        cont5++;
        if (DS.getOutputAsInteger(j) == prediction)
          hints5++; 
        matriz = obtener_matriz_confusion(DS.getOutputAsInteger(j), prediction);
        tp5 += matriz[0];
        fp5 += matriz[1];
        fn5 += matriz[2];
        tn5 += matriz[3];
      } 
      matriz = obtener_matriz_confusion(this.train.getOutputAsInteger(j), prediction);
      tp += matriz[0];
      fp += matriz[1];
      fn += matriz[2];
      tn += matriz[3];
      if (prediction < 0) {
        this.nUncover++;
        int n = DS.getOutputAsInteger(j);
        this.nUncoverClas[n] = this.nUncoverClas[n] + 1;
      } 
    } 
    this.fitnessEv = compute_f1_score(tp, fp, fn, tn);
    System.out.println("Porcentaje de acierto en cada caso:");
    double[] fscores = { compute_f1_score(tp0, fp0, fn0, tn0), compute_f1_score(tp1, fp1, fn1, tn1), compute_f1_score(tp2, fp2, fn2, tn2), compute_f1_score(tp3, fp3, fn3, tn3), compute_f1_score(tp4, fp4, fn4, tn4), compute_f1_score(tp5, fp5, fn5, tn5) };
    System.out.println("Caso 0: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp0, fp0, fn0, tn0)) }) + " numero de ejemplos: " + cont0);
    System.out.println("Caso 1: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp1, fp1, fn1, tn1)) }) + " numero de ejemplos: " + cont1);
    System.out.println("Caso 2: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp2, fp2, fn2, tn2)) }) + " numero de ejemplos: " + cont2);
    System.out.println("Caso 3: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp3, fp3, fn3, tn3)) }) + " numero de ejemplos: " + cont3);
    System.out.println("Caso 4: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp4, fp4, fn4, tn4)) }) + " numero de ejemplos: " + cont4);
    System.out.println("Caso 5: " + String.format("%.3f", new Object[] { Double.valueOf(compute_f1_score(tp5, fp5, fn5, tn5)) }) + " numero de ejemplos: " + cont5);
    return fscores;
  }
  
  private int[] obtener_matriz_confusion(int claseReal, int clasePredicha) {
    int[] matriz = new int[4];
    for (int i = 0; i < 4; i++)
      matriz[i] = 0; 
    if (claseReal == 0)
      if (clasePredicha == 0) {
        matriz[0] = matriz[0] + 1;
      } else {
        matriz[1] = matriz[1] + 1;
      }  
    if (claseReal == 1)
      if (clasePredicha == 0) {
        matriz[2] = matriz[2] + 1;
      } else {
        matriz[3] = matriz[3] + 1;
      }  
    return matriz;
  }
  
  private double compute_f1_score(int tp, int fp, int fn, int tn) {
    double fscore = 0.0D;
    double rec0Ev = 0.0D;
    double rec1Ev = 0.0D;
    double precision = 0.0D;
    rec0Ev = ((tp + fn) == 0) ? 0.0D : ((double)tp / (tp + fn));
    rec1Ev = ((tn + fp) == 0) ? 0.0D : ((double)tn / (tn + fp));
    precision = ((tp + fp) == 0) ? 0.0D : ((double)tp / (tp + fp));
    fscore = ((rec0Ev + precision) == 0.0D) ? 0.0D : (2.0D * (rec0Ev * precision) / (rec0Ev + precision));
    return fscore;
  }
  
  public void evaluate(double[] gene, int[] selected) {
    int tp = 0;
    int tn = 0;
    int fp = 0;
    int fn = 0;
    this.dataBase.decode(gene);
    recomputeQualityMeasures();
    int nHits = 0;
    this.nUncover = 0;
    int j;
    for (j = 0; j < this.train.getnClasses(); j++)
      this.nUncoverClas[j] = 0; 
    for (j = 0; j < this.train.size(); j++) {
      int prediction = FRM(this.train.getExample(j), selected);
      //System.out.println(j + ": " + prediction + ", " + this.train.getOutputAsInteger(j));
      if (this.train.getOutputAsInteger(j) == prediction)
        nHits++; 
      if (this.train.getOutputAsInteger(j) == 0)
        if (prediction == 0) {
          tp++;
        } else {
          fp++;
        }  
      if (this.train.getOutputAsInteger(j) == 1)
        if (prediction == 0) {
          fn++;
        } else {
          tn++;
        }  
      if (prediction < 0) {
        this.nUncover++;
        int n = this.train.getOutputAsInteger(j);
        this.nUncoverClas[n] = this.nUncoverClas[n] + 1;
      } 
    } 
    this.rec0 = ((tp + fp) == 0) ? 0.0D : ((double)tp / (tp + fp));
    this.rec1 = ((tn + fn) == 0) ? 0.0D : ((double)tn / (tn + fn));
    double precision = ((tp + fn) == 0) ? 0.0D : ((double)tp / (tp + fn));
    this.fitness = ((this.rec0 + precision) == 0.0D) ? 0.0D : (2.0D * (this.rec0 * precision) / (this.rec0 + precision));
  }
  
  public int FRM(double[] example) {
    switch (this.typeInference) {
      case 0:
        return FRM_WR(example);
      case 2:
        return FRM_Choquet(example);
      case 3:
        return FRM_Prob_Sum(example);
      case 4:
        return FRM_dChoquet(example);
      case 5:
        return FRM_dChoquet(example);
      case 6:
        return FRM_Choquet(example);
      case 7:
        return FRM_AC(example);
    } 
    return FRM_AC(example);
  }
  
  public int[] FRM_stats(double[] example, int typeInference) {
    switch (typeInference) {
      case 0:
        return FRM_WR_stats(example);
      case 2:
        return FRM_Choquet_stats(example);
      case 3:
        return FRM_Prob_Sum_stats(example);
    } 
    return FRM_AC_stats(example);
  }
  
  public int[] FRM_fired_rules_stats(double[] example, int typeInference) {
    switch (typeInference) {
      case 0:
        return FRM_WR_stats(example);
      case 2:
        return FRM_Choquet_stats(example);
      case 3:
        return FRM_Prob_Sum_stats(example);
    } 
    return FRM_AC_fired_rules_stats(example);
  }
  
  public int FRM(double[] example, int[] selected) {
    switch (this.typeInference) {
      case 0:
        return FRM_WR(example, selected);
      case 2:
        return FRM_Choquet(example, selected);
      case 3:
        return FRM_Prob_Sum(example, selected);
      case 4:
        return FRM_dChoquet(example, selected);
      case 5:
        return FRM_dChoquet(example, selected);
      case 6:
        return FRM_Choquet(example, selected);
      case 7:
        return FRM_AC(example, selected);
    } 
    return FRM_AC(example, selected);
  }
  
  private int FRM_WR(double[] example, int[] selected) {
    double max = 0.0D;
    int clas = this.defaultRule;
    for (int i = 0; i < this.ruleBase.size(); i++) {
      Rule r;
      double degree;
      if (selected[i] > 0 && (degree = (r = this.ruleBase.get(i)).matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut)) > max) {
        max = degree;
        clas = r.getClas();
      } 
    } 
    return clas;
  }
  
  private int FRM_WR(double[] example) {
    double max = 0.0D;
    int clas = this.defaultRule;
    for (int i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      double degree = r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut);
      if (degree > max) {
        max = degree;
        clas = r.getClas();
      } 
    } 
    return clas;
  }
  
  private int FRM_AC(double[] example, int[] selected) {
    int clas = this.defaultRule;
    double[] degreeClass = new double[this.train.getnClasses()];
    int i;
    for (i = 0; i < this.train.getnClasses(); i++)
      degreeClass[i] = 0.0D; 
    for (i = 0; i < this.ruleBase.size(); i++) {
      if (selected[i] > 0) {
        Rule r = this.ruleBase.get(i);
        double degree = r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut);
        int n = r.getClas();
        degreeClass[n] = degreeClass[n] + degree;
      } 
    } 
    double maxDegree = 0.0D;
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      if (degreeClass[i] > maxDegree) {
        maxDegree = degreeClass[i];
        clas = i;
        cont = 0;
      } else if (degreeClass[i] == maxDegree) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    return clas;
  }
  
  private int FRM_AC(double[] example) {
    int clas = this.defaultRule;
    double[] degreeClass = new double[this.train.getnClasses()];
    int i;
    for (i = 0; i < this.train.getnClasses(); i++)
      degreeClass[i] = 0.0D; 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      double degree = r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut);
      int n = r.getClas();
      degreeClass[n] = degreeClass[n] + degree;
    } 
    double maxDegree = 0.0D;
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      if (degreeClass[i] > maxDegree) {
        maxDegree = degreeClass[i];
        clas = i;
        cont = 0;
      } else if (degreeClass[i] == maxDegree) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    return clas;
  }
  
  private int FRM_Prob_Sum(double[] example, int[] selected) {
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    int clas = this.defaultRule;
    double[] degreeClass = new double[this.train.getnClasses()];
    int i;
    for (i = 0; i < this.train.getnClasses(); i++)
      gAsoc.add(new ArrayList()); 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r;
      Double degree;
      if (selected[i] > 0 && (degree = Double.valueOf((r = this.ruleBase.get(i)).matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut))).doubleValue() > 0.0D)
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(degree); 
    } 
    for (int j = 0; j < gAsoc.size(); j++) {
      Double sum;
      if (!((ArrayList)gAsoc.get(j)).isEmpty()) {
        sum = ((ArrayList<Double>)gAsoc.get(j)).get(0);
        for (int k = 1; k < ((ArrayList)gAsoc.get(j)).size(); k++)
          sum = Double.valueOf(sum.doubleValue() + ((Double)((ArrayList<Double>)gAsoc.get(j)).get(k)).doubleValue() - sum.doubleValue() * ((Double)((ArrayList<Double>)gAsoc.get(j)).get(k)).doubleValue()); 
      } else {
        sum = Double.valueOf(0.0D);
      } 
      degreeClass[j] = sum.doubleValue();
    } 
    Double maxDegree = Double.valueOf(0.0D);
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      if (degreeClass[i] > maxDegree.doubleValue()) {
        maxDegree = Double.valueOf(degreeClass[i]);
        clas = i;
        cont = 0;
      } else if (degreeClass[i] == maxDegree.doubleValue()) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    return clas;
  }
  
  private int FRM_Prob_Sum(double[] example) {
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    int clas = this.defaultRule;
    double[] degreeClass = new double[this.train.getnClasses()];
    int i;
    for (i = 0; i < this.train.getnClasses(); i++)
      gAsoc.add(new ArrayList()); 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      Double degree = Double.valueOf(r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut));
      if (degree.doubleValue() > 0.0D)
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(degree); 
    } 
    for (int j = 0; j < gAsoc.size(); j++) {
      Double sum;
      if (!((ArrayList)gAsoc.get(j)).isEmpty()) {
        sum = ((ArrayList<Double>)gAsoc.get(j)).get(0);
        for (int k = 1; k < ((ArrayList)gAsoc.get(j)).size(); k++)
          sum = Double.valueOf(sum.doubleValue() + ((Double)((ArrayList<Double>)gAsoc.get(j)).get(k)).doubleValue() - sum.doubleValue() * ((Double)((ArrayList<Double>)gAsoc.get(j)).get(k)).doubleValue()); 
      } else {
        sum = Double.valueOf(0.0D);
      } 
      degreeClass[j] = sum.doubleValue();
    } 
    Double maxDegree = Double.valueOf(0.0D);
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      if (degreeClass[i] > maxDegree.doubleValue()) {
        maxDegree = Double.valueOf(degreeClass[i]);
        clas = i;
        cont = 0;
      } else if (degreeClass[i] == maxDegree.doubleValue()) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    return clas;
  }
  
  private int FRM_Choquet(double[] example, int[] selected) {
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    ArrayList<ArrayList<Integer>> firedRules = new ArrayList();
    int clas = this.defaultRule;
    int i;
    for (i = 0; i < this.train.getnClasses(); i++) {
      gAsoc.add(new ArrayList());
      firedRules.add(new ArrayList());
    } 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r;
      Double degree;
      if (selected[i] > 0 && (degree = Double.valueOf((r = this.ruleBase.get(i)).matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut))).doubleValue() > 0.0D) {
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(degree);
        ((ArrayList<Integer>)firedRules.get(r.getClas())).add(Integer.valueOf(i));
      } 
    } 
    Double maxDegree = Double.valueOf(0.0D);
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      Double agregated = !((ArrayList)gAsoc.get(i)).isEmpty() ? agChoquet(gAsoc.get(i), firedRules.get(i), this.dataBase.exp[i], 1.0D, 1.0D) : Double.valueOf(0.0D);
      if (agregated.doubleValue() > maxDegree.doubleValue()) {
        maxDegree = agregated;
        clas = i;
        cont = 0;
      } else if (Objects.equals(agregated, maxDegree)) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    return clas;
  }
  
  private int FRM_dChoquet(double[] example, int[] selected) {
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    ArrayList<ArrayList<Integer>> firedRules = new ArrayList();
    int clas = this.defaultRule;
    int i;
    for (i = 0; i < this.train.getnClasses(); i++) {
      gAsoc.add(new ArrayList());
      firedRules.add(new ArrayList());
    } 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r;
      Double degree;
      if (selected[i] > 0 && (degree = Double.valueOf((r = this.ruleBase.get(i)).matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut))).doubleValue() > 0.0D) {
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(degree);
        ((ArrayList<Integer>)firedRules.get(r.getClas())).add(Integer.valueOf(i));
      } 
    } 
    Double maxDegree = Double.valueOf(0.0D);
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      Double agregated = !((ArrayList)gAsoc.get(i)).isEmpty() ? agChoquet(gAsoc.get(i), firedRules.get(i), this.dataBase.exp[i], this.dataBase.aut1[i], this.dataBase.aut2[i]) : Double.valueOf(0.0D);
      if (agregated.doubleValue() > maxDegree.doubleValue()) {
        maxDegree = agregated;
        clas = i;
        cont = 0;
      } else if (Objects.equals(agregated, maxDegree)) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    return clas;
  }
  
  private int FRM_Choquet(double[] example) {
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    ArrayList<ArrayList<Integer>> firedRules = new ArrayList();
    int clas = this.defaultRule;
    int i;
    for (i = 0; i < this.train.getnClasses(); i++) {
      gAsoc.add(new ArrayList());
      firedRules.add(new ArrayList());
    } 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      Double degree = Double.valueOf(r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut));
      if (degree.doubleValue() > 0.0D) {
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(degree);
        ((ArrayList<Integer>)firedRules.get(r.getClas())).add(Integer.valueOf(i));
      } 
    } 
    Double maxDegree = Double.valueOf(0.0D);
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      Double agregated = !((ArrayList)gAsoc.get(i)).isEmpty() ? agChoquet(gAsoc.get(i), firedRules.get(i), this.dataBase.exp[i], 1.0D, 1.0D) : Double.valueOf(0.0D);
      if (agregated.doubleValue() > maxDegree.doubleValue()) {
        maxDegree = agregated;
        clas = i;
        cont = 0;
      } else if (Objects.equals(agregated, maxDegree)) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    return clas;
  }
  
  private int FRM_dChoquet(double[] example) {
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    ArrayList<ArrayList<Integer>> firedRules = new ArrayList();
    int clas = this.defaultRule;
    int i;
    for (i = 0; i < this.train.getnClasses(); i++) {
      gAsoc.add(new ArrayList());
      firedRules.add(new ArrayList());
    } 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      Double degree = Double.valueOf(r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut));
      if (degree.doubleValue() > 0.0D) {
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(degree);
        ((ArrayList<Integer>)firedRules.get(r.getClas())).add(Integer.valueOf(i));
      } 
    } 
    Double maxDegree = Double.valueOf(0.0D);
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      Double agregated = !((ArrayList)gAsoc.get(i)).isEmpty() ? agChoquet(gAsoc.get(i), firedRules.get(i), this.dataBase.exp[i], this.dataBase.aut1[i], this.dataBase.aut2[i]) : Double.valueOf(0.0D);
      if (agregated.doubleValue() > maxDegree.doubleValue()) {
        maxDegree = agregated;
        clas = i;
        cont = 0;
      } else if (Objects.equals(agregated, maxDegree)) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    return clas;
  }
  
  private int[] FRM_WR_stats(double[] example) {
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    int[] salida = new int[2];
    double[] degreeClass = new double[this.train.getnClasses()];
    int i;
    for (i = 0; i < this.train.getnClasses(); i++)
      degreeClass[i] = 0.0D; 
    for (i = 0; i < this.train.getnClasses(); i++)
      gAsoc.add(new ArrayList()); 
    double max = 0.0D;
    int clas = this.defaultRule;
    int caso = -1;
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      double degree = r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut);
      if (degree > 0.0D) {
        int n = r.getClas();
        degreeClass[n] = degreeClass[n] + degree;
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(Double.valueOf(degree));
      } 
      if (degree > max) {
        max = degree;
        clas = r.getClas();
      } 
    } 
    int numEltosClass0 = ((ArrayList)gAsoc.get(0)).size();
    int numEltosClass1;
    if ((((numEltosClass0 == 1) ? 1 : 0) & (((numEltosClass1 = ((ArrayList)gAsoc.get(1)).size()) > 1) ? 1 : 0)) == 0) {
      if ((((numEltosClass0 > 1) ? 1 : 0) & ((numEltosClass1 == 1) ? 1 : 0)) != 0) {
        caso = 0;
        salida[0] = clas;
        salida[1] = caso;
        return salida;
      } 
      if ((((numEltosClass0 > 1) ? 1 : 0) & ((numEltosClass1 > 1) ? 1 : 0)) != 0) {
        int situacion = situacionIntervalos(((Double)Collections.<Double>min(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>min(gAsoc.get(1))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(1))).doubleValue());
        caso = obtener_caso(situacion, degreeClass[0], degreeClass[1]);
      } 
      salida[0] = clas;
      salida[1] = caso;
      return salida;
    } 
    caso = 0;
    salida[0] = clas;
    salida[1] = caso;
    return salida;
  }
  
  private int obtener_caso(int situacion, double suma0, double suma1) {
    int caso = -1;
    if ((((situacion == 0) ? 1 : 0) & ((suma1 > suma0) ? 1 : 0)) != 0) {
      caso = 1;
    } else if ((((situacion == 1) ? 1 : 0) & ((suma0 > suma1) ? 1 : 0)) != 0) {
      caso = 1;
    } else if ((((situacion == 2) ? 1 : 0) & ((suma1 > suma0) ? 1 : 0)) != 0) {
      caso = 2;
    } else if ((((situacion == 3) ? 1 : 0) & ((suma0 > suma1) ? 1 : 0)) != 0) {
      caso = 2;
    } else if ((((situacion == 2) ? 1 : 0) & ((suma0 >= suma1) ? 1 : 0)) != 0) {
      caso = 3;
    } else if ((((situacion == 3) ? 1 : 0) & ((suma1 >= suma0) ? 1 : 0)) != 0) {
      caso = 3;
    } else if ((((situacion == 4) ? 1 : 0) & ((suma1 > suma0) ? 1 : 0)) != 0) {
      caso = 4;
    } else if ((((situacion == 5) ? 1 : 0) & ((suma0 > suma1) ? 1 : 0)) != 0) {
      caso = 4;
    } else if ((((situacion == 5) ? 1 : 0) & ((suma1 >= suma0) ? 1 : 0)) != 0) {
      caso = 5;
    } else if ((((situacion == 4) ? 1 : 0) & ((suma0 >= suma1) ? 1 : 0)) != 0) {
      caso = 5;
    } 
    return caso;
  }
  
  private int situacionIntervalos(double low1, double up1, double low2, double up2) {
    int situacion = -1;
    if (low1 > up2) {
      situacion = 0;
    } else if (low2 > up1) {
      situacion = 1;
    } else if ((((low1 <= low2) ? 1 : 0) & ((up2 <= up1) ? 1 : 0)) != 0) {
      situacion = 2;
    } else if ((((low2 <= low1) ? 1 : 0) & ((up1 <= up2) ? 1 : 0)) != 0) {
      situacion = 3;
    } else if ((((low2 <= low1) ? 1 : 0) & ((up2 <= up1) ? 1 : 0)) != 0) {
      situacion = 4;
    } else if ((((low1 <= low2) ? 1 : 0) & ((up1 <= up2) ? 1 : 0)) != 0) {
      situacion = 5;
    } 
    return situacion;
  }
  
  private int[] FRM_AC_stats(double[] example) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: iconst_2
    //   10: newarray int
    //   12: astore #5
    //   14: iconst_0
    //   15: istore_3
    //   16: iload_3
    //   17: aload_0
    //   18: getfield train : LFARCHD/myDataset;
    //   21: invokevirtual getnClasses : ()I
    //   24: if_icmpge -> 46
    //   27: aload #4
    //   29: new java/util/ArrayList
    //   32: dup
    //   33: invokespecial <init> : ()V
    //   36: invokevirtual add : (Ljava/lang/Object;)Z
    //   39: pop
    //   40: iinc #3, 1
    //   43: goto -> 16
    //   46: aload_0
    //   47: getfield defaultRule : I
    //   50: istore #6
    //   52: iconst_m1
    //   53: istore #7
    //   55: aload_0
    //   56: getfield train : LFARCHD/myDataset;
    //   59: invokevirtual getnClasses : ()I
    //   62: newarray double
    //   64: astore #8
    //   66: iconst_0
    //   67: istore_3
    //   68: iload_3
    //   69: aload_0
    //   70: getfield train : LFARCHD/myDataset;
    //   73: invokevirtual getnClasses : ()I
    //   76: if_icmpge -> 90
    //   79: aload #8
    //   81: iload_3
    //   82: dconst_0
    //   83: dastore
    //   84: iinc #3, 1
    //   87: goto -> 68
    //   90: iconst_0
    //   91: istore_3
    //   92: iload_3
    //   93: aload_0
    //   94: getfield ruleBase : Ljava/util/ArrayList;
    //   97: invokevirtual size : ()I
    //   100: if_icmpge -> 197
    //   103: aload_0
    //   104: getfield ruleBase : Ljava/util/ArrayList;
    //   107: iload_3
    //   108: invokevirtual get : (I)Ljava/lang/Object;
    //   111: checkcast FARCHD/Rule
    //   114: astore #9
    //   116: aload #9
    //   118: aload_1
    //   119: aload_0
    //   120: getfield typeRW : I
    //   123: aload_0
    //   124: getfield typeAggMatch : I
    //   127: aload_0
    //   128: getfield dataBase : LFARCHD/DataBase;
    //   131: getfield tuneCut : I
    //   134: invokevirtual matching : ([DIII)D
    //   137: dstore #10
    //   139: aload #9
    //   141: invokevirtual getClas : ()I
    //   144: istore #12
    //   146: aload #8
    //   148: iload #12
    //   150: aload #8
    //   152: iload #12
    //   154: daload
    //   155: dload #10
    //   157: dadd
    //   158: dastore
    //   159: dload #10
    //   161: dconst_0
    //   162: dcmpl
    //   163: ifgt -> 169
    //   166: goto -> 191
    //   169: aload #4
    //   171: aload #9
    //   173: invokevirtual getClas : ()I
    //   176: invokevirtual get : (I)Ljava/lang/Object;
    //   179: checkcast java/util/ArrayList
    //   182: dload #10
    //   184: invokestatic valueOf : (D)Ljava/lang/Double;
    //   187: invokevirtual add : (Ljava/lang/Object;)Z
    //   190: pop
    //   191: iinc #3, 1
    //   194: goto -> 92
    //   197: dconst_0
    //   198: dstore #9
    //   200: iconst_0
    //   201: istore #11
    //   203: iconst_0
    //   204: istore_3
    //   205: iload_3
    //   206: aload_0
    //   207: getfield train : LFARCHD/myDataset;
    //   210: invokevirtual getnClasses : ()I
    //   213: if_icmpge -> 263
    //   216: aload #8
    //   218: iload_3
    //   219: daload
    //   220: dload #9
    //   222: dcmpl
    //   223: ifle -> 241
    //   226: aload #8
    //   228: iload_3
    //   229: daload
    //   230: dstore #9
    //   232: iload_3
    //   233: istore #6
    //   235: iconst_0
    //   236: istore #11
    //   238: goto -> 257
    //   241: aload #8
    //   243: iload_3
    //   244: daload
    //   245: dload #9
    //   247: dcmpl
    //   248: ifeq -> 254
    //   251: goto -> 257
    //   254: iinc #11, 1
    //   257: iinc #3, 1
    //   260: goto -> 205
    //   263: aload #4
    //   265: iconst_0
    //   266: invokevirtual get : (I)Ljava/lang/Object;
    //   269: checkcast java/util/ArrayList
    //   272: invokevirtual size : ()I
    //   275: istore #12
    //   277: iload #12
    //   279: iconst_1
    //   280: if_icmpne -> 287
    //   283: iconst_1
    //   284: goto -> 288
    //   287: iconst_0
    //   288: aload #4
    //   290: iconst_1
    //   291: invokevirtual get : (I)Ljava/lang/Object;
    //   294: checkcast java/util/ArrayList
    //   297: invokevirtual size : ()I
    //   300: dup
    //   301: istore_2
    //   302: iconst_1
    //   303: if_icmple -> 310
    //   306: iconst_1
    //   307: goto -> 311
    //   310: iconst_0
    //   311: iand
    //   312: ifne -> 340
    //   315: iload #12
    //   317: iconst_1
    //   318: if_icmple -> 325
    //   321: iconst_1
    //   322: goto -> 326
    //   325: iconst_0
    //   326: iload_2
    //   327: iconst_1
    //   328: if_icmpne -> 335
    //   331: iconst_1
    //   332: goto -> 336
    //   335: iconst_0
    //   336: iand
    //   337: ifeq -> 346
    //   340: iconst_0
    //   341: istore #7
    //   343: goto -> 465
    //   346: iload #12
    //   348: iconst_1
    //   349: if_icmple -> 356
    //   352: iconst_1
    //   353: goto -> 357
    //   356: iconst_0
    //   357: iload_2
    //   358: iconst_1
    //   359: if_icmple -> 366
    //   362: iconst_1
    //   363: goto -> 367
    //   366: iconst_0
    //   367: iand
    //   368: ifeq -> 465
    //   371: aload_0
    //   372: aload #4
    //   374: iconst_0
    //   375: invokevirtual get : (I)Ljava/lang/Object;
    //   378: checkcast java/util/Collection
    //   381: invokestatic min : (Ljava/util/Collection;)Ljava/lang/Object;
    //   384: checkcast java/lang/Double
    //   387: invokevirtual doubleValue : ()D
    //   390: aload #4
    //   392: iconst_0
    //   393: invokevirtual get : (I)Ljava/lang/Object;
    //   396: checkcast java/util/Collection
    //   399: invokestatic max : (Ljava/util/Collection;)Ljava/lang/Object;
    //   402: checkcast java/lang/Double
    //   405: invokevirtual doubleValue : ()D
    //   408: aload #4
    //   410: iconst_1
    //   411: invokevirtual get : (I)Ljava/lang/Object;
    //   414: checkcast java/util/Collection
    //   417: invokestatic min : (Ljava/util/Collection;)Ljava/lang/Object;
    //   420: checkcast java/lang/Double
    //   423: invokevirtual doubleValue : ()D
    //   426: aload #4
    //   428: iconst_1
    //   429: invokevirtual get : (I)Ljava/lang/Object;
    //   432: checkcast java/util/Collection
    //   435: invokestatic max : (Ljava/util/Collection;)Ljava/lang/Object;
    //   438: checkcast java/lang/Double
    //   441: invokevirtual doubleValue : ()D
    //   444: invokespecial situacionIntervalos : (DDDD)I
    //   447: istore #13
    //   449: aload_0
    //   450: iload #13
    //   452: aload #8
    //   454: iconst_0
    //   455: daload
    //   456: aload #8
    //   458: iconst_1
    //   459: daload
    //   460: invokespecial obtener_caso : (IDD)I
    //   463: istore #7
    //   465: iload #11
    //   467: ifle -> 476
    //   470: aload_0
    //   471: getfield defaultRule : I
    //   474: istore #6
    //   476: aload #5
    //   478: iconst_0
    //   479: iload #6
    //   481: iastore
    //   482: aload #5
    //   484: iconst_1
    //   485: iload #7
    //   487: iastore
    //   488: aload #5
    //   490: areturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #1301	-> 0
    //   #1302	-> 9
    //   #1303	-> 14
    //   #1304	-> 27
    //   #1303	-> 40
    //   #1306	-> 46
    //   #1307	-> 52
    //   #1308	-> 55
    //   #1309	-> 66
    //   #1310	-> 79
    //   #1309	-> 84
    //   #1312	-> 90
    //   #1313	-> 103
    //   #1314	-> 116
    //   #1315	-> 139
    //   #1316	-> 146
    //   #1317	-> 159
    //   #1318	-> 169
    //   #1312	-> 191
    //   #1320	-> 197
    //   #1321	-> 200
    //   #1322	-> 203
    //   #1323	-> 216
    //   #1324	-> 226
    //   #1325	-> 232
    //   #1326	-> 235
    //   #1327	-> 238
    //   #1329	-> 241
    //   #1330	-> 254
    //   #1322	-> 257
    //   #1332	-> 263
    //   #1333	-> 277
    //   #1334	-> 340
    //   #1335	-> 346
    //   #1336	-> 371
    //   #1337	-> 449
    //   #1339	-> 465
    //   #1340	-> 470
    //   #1342	-> 476
    //   #1343	-> 482
    //   #1344	-> 488
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   116	75	9	r	LFARCHD/Rule;
    //   139	52	10	degree	D
    //   146	45	12	n	I
    //   449	16	13	situacion	I
    //   0	491	0	this	LFARCHD/RuleBase;
    //   0	491	1	example	[D
    //   302	189	2	numEltosClass1	I
    //   16	475	3	i	I
    //   9	482	4	gAsoc	Ljava/util/ArrayList;
    //   14	477	5	salida	[I
    //   52	439	6	clas	I
    //   55	436	7	caso	I
    //   66	425	8	degreeClass	[D
    //   200	291	9	maxDegree	D
    //   203	288	11	cont	I
    //   277	214	12	numEltosClass0	I
    int numEltosClass1;
        int i;
        ArrayList gAsoc = new ArrayList();
        int[] salida = new int[2];
        for (i = 0; i < this.train.getnClasses(); ++i) {
            gAsoc.add(new ArrayList());
        }
        int clas = this.defaultRule;
        int caso = -1;
        double[] degreeClass = new double[this.train.getnClasses()];
        for (i = 0; i < this.train.getnClasses(); ++i) {
            degreeClass[i] = 0.0;
        }
        for (i = 0; i < this.ruleBase.size(); ++i) {
            Rule r = this.ruleBase.get(i);
            double degree = r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut);
            int n = r.getClas();
            degreeClass[n] = degreeClass[n] + degree;
            if (!(degree > 0.0)) continue;
            ((ArrayList)gAsoc.get(r.getClas())).add(degree);
        }
        double maxDegree = 0.0;
        int cont = 0;
        for (i = 0; i < this.train.getnClasses(); ++i) {
            if (degreeClass[i] > maxDegree) {
                maxDegree = degreeClass[i];
                clas = i;
                cont = 0;
                continue;
            }
            if (degreeClass[i] != maxDegree) continue;
            ++cont;
        }
        int numEltosClass0 = ((ArrayList)gAsoc.get(0)).size();
        if (numEltosClass0 == 1 & (numEltosClass1 = ((ArrayList)gAsoc.get(1)).size()) > 1 || numEltosClass0 > 1 & numEltosClass1 == 1) {
            caso = 0;
        } else if (numEltosClass0 > 1 & numEltosClass1 > 1) {
            int situacion = this.situacionIntervalos((Double)Collections.min((Collection)gAsoc.get(0)), (Double)Collections.max((Collection)gAsoc.get(0)), (Double)Collections.min((Collection)gAsoc.get(1)), (Double)Collections.max((Collection)gAsoc.get(1)));
            caso = this.obtener_caso(situacion, degreeClass[0], degreeClass[1]);
        }
        if (cont > 0) {
            clas = this.defaultRule;
        }
        salida[0] = clas;
        salida[1] = caso;
        return salida;
  }
  
  private int[] FRM_AC_fired_rules_stats(double[] example) {
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    int[] salida = new int[3];
    int i;
    for (i = 0; i < this.train.getnClasses(); i++)
      gAsoc.add(new ArrayList()); 
    int clas = this.defaultRule;
    double[] degreeClass = new double[this.train.getnClasses()];
    for (i = 0; i < this.train.getnClasses(); i++)
      degreeClass[i] = 0.0D; 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      double degree = r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut);
      int n = r.getClas();
      degreeClass[n] = degreeClass[n] + degree;
      if (degree > 0.0D)
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(Double.valueOf(degree)); 
    } 
    double maxDegree = 0.0D;
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      if (degreeClass[i] > maxDegree) {
        maxDegree = degreeClass[i];
        clas = i;
        cont = 0;
      } else if (degreeClass[i] == maxDegree) {
        cont++;
      } 
    } 
    int caso = -1;
    int numEltosClass0 = ((ArrayList)gAsoc.get(0)).size();
    int numEltosClass1;
    if ((((numEltosClass0 == 1) ? 1 : 0) & (((numEltosClass1 = ((ArrayList)gAsoc.get(1)).size()) > 1) ? 1 : 0)) != 0) {
      int situacion = situacionIntervalos(((Double)Collections.<Double>min(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>min(gAsoc.get(1))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(1))).doubleValue());
      if ((((situacion == 0) ? 1 : 0) & ((degreeClass[1] > degreeClass[0]) ? 1 : 0)) != 0) {
        caso = 0;
        salida[1] = numEltosClass1;
        salida[2] = numEltosClass0;
      } 
    } else if ((((numEltosClass0 > 1) ? 1 : 0) & ((numEltosClass1 == 1) ? 1 : 0)) != 0) {
      int situacion = situacionIntervalos(((Double)Collections.<Double>min(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>min(gAsoc.get(1))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(1))).doubleValue());
      if ((((situacion == 1) ? 1 : 0) & ((degreeClass[0] > degreeClass[1]) ? 1 : 0)) != 0) {
        caso = 0;
        salida[1] = numEltosClass0;
        salida[2] = numEltosClass1;
      } 
    } else if ((((numEltosClass0 > 1) ? 1 : 0) & ((numEltosClass1 > 1) ? 1 : 0)) != 0) {
      if (numEltosClass0 < numEltosClass1) {
        int situacion2 = situacionIntervalos(((Double)Collections.<Double>min(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>min(gAsoc.get(1))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(1))).doubleValue());
        if ((situacion2 == 0 || situacion2 == 4) && degreeClass[1] > degreeClass[0]) {
          caso = 1;
          salida[1] = numEltosClass1;
          salida[2] = numEltosClass0;
        } 
      } else {
        int situacion;
        if (numEltosClass0 > numEltosClass1 && ((situacion = situacionIntervalos(((Double)Collections.<Comparable>min(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Comparable>max(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Comparable>min(gAsoc.get(1))).doubleValue(), ((Double)Collections.<Comparable>max(gAsoc.get(1))).doubleValue())) == 1 || situacion == 5) && degreeClass[0] > degreeClass[1]) {
          caso = 1;
          salida[1] = numEltosClass0;
          salida[2] = numEltosClass1;
        } 
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    salida[0] = clas;
    return salida;
  }
  
  private int[] FRM_Prob_Sum_stats(double[] example) {
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    int[] salida = new int[2];
    double[] degreeClass = new double[this.train.getnClasses()];
    double[] degreeClassSP = new double[this.train.getnClasses()];
    int i;
    for (i = 0; i < this.train.getnClasses(); i++) {
      degreeClass[i] = 0.0D;
      degreeClassSP[i] = 0.0D;
    } 
    int clas = this.defaultRule;
    int caso = -1;
    degreeClass = new double[this.train.getnClasses()];
    for (i = 0; i < this.train.getnClasses(); i++)
      gAsoc.add(new ArrayList()); 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      Double degree = Double.valueOf(r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut));
      if (degree.doubleValue() > 0.0D) {
        int n = r.getClas();
        degreeClass[n] = degreeClass[n] + degree.doubleValue();
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(degree);
      } 
    } 
    for (int j = 0; j < gAsoc.size(); j++) {
      Double sum;
      if (!((ArrayList)gAsoc.get(j)).isEmpty()) {
        sum = ((ArrayList<Double>)gAsoc.get(j)).get(0);
        for (int k = 1; k < ((ArrayList)gAsoc.get(j)).size(); k++)
          sum = Double.valueOf(sum.doubleValue() + ((Double)((ArrayList<Double>)gAsoc.get(j)).get(k)).doubleValue() - sum.doubleValue() * ((Double)((ArrayList<Double>)gAsoc.get(j)).get(k)).doubleValue()); 
      } else {
        sum = Double.valueOf(0.0D);
      } 
      degreeClassSP[j] = sum.doubleValue();
    } 
    Double maxDegree = Double.valueOf(0.0D);
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      if (degreeClassSP[i] > maxDegree.doubleValue()) {
        maxDegree = Double.valueOf(degreeClassSP[i]);
        clas = i;
        cont = 0;
      } else if (degreeClassSP[i] == maxDegree.doubleValue()) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    int numEltosClass1, numEltosClass0;
    if (((((numEltosClass0 = ((ArrayList)gAsoc.get(0)).size()) == 1) ? 1 : 0) & (((numEltosClass1 = ((ArrayList)gAsoc.get(1)).size()) > 1) ? 1 : 0)) == 0) {
      if ((((numEltosClass0 > 1) ? 1 : 0) & ((numEltosClass1 == 1) ? 1 : 0)) != 0) {
        caso = 0;
        salida[0] = clas;
        salida[1] = caso;
        return salida;
      } 
      if ((((numEltosClass0 > 1) ? 1 : 0) & ((numEltosClass1 > 1) ? 1 : 0)) != 0) {
        int situacion = situacionIntervalos(((Double)Collections.<Double>min(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>min(gAsoc.get(1))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(1))).doubleValue());
        caso = obtener_caso(situacion, degreeClass[0], degreeClass[1]);
      } 
      salida[0] = clas;
      salida[1] = caso;
      return salida;
    } 
    caso = 0;
    salida[0] = clas;
    salida[1] = caso;
    return salida;
  }
  
  private int[] FRM_Choquet_stats(double[] example) {
    int[] salida = new int[2];
    double[] degreeClass = new double[this.train.getnClasses()];
    int i;
    for (i = 0; i < this.train.getnClasses(); i++)
      degreeClass[i] = 0.0D; 
    ArrayList<ArrayList<Double>> gAsoc = new ArrayList();
    ArrayList<ArrayList<Integer>> firedRules = new ArrayList();
    int clas = this.defaultRule;
    int caso = -1;
    for (i = 0; i < this.train.getnClasses(); i++) {
      gAsoc.add(new ArrayList());
      firedRules.add(new ArrayList());
    } 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      Double degree = Double.valueOf(r.matching(example, this.typeRW, this.typeAggMatch, this.dataBase.tuneCut));
      if (degree.doubleValue() > 0.0D) {
        int n = r.getClas();
        degreeClass[n] = degreeClass[n] + degree.doubleValue();
        ((ArrayList<Double>)gAsoc.get(r.getClas())).add(degree);
        ((ArrayList<Integer>)firedRules.get(r.getClas())).add(Integer.valueOf(i));
      } 
    } 
    Double maxDegree = Double.valueOf(0.0D);
    int cont = 0;
    for (i = 0; i < this.train.getnClasses(); i++) {
      Double agregated = !((ArrayList)gAsoc.get(i)).isEmpty() ? agChoquet(gAsoc.get(i), firedRules.get(i), this.dataBase.exp[i], this.dataBase.aut1[i], this.dataBase.aut2[i]) : Double.valueOf(0.0D);
      if (agregated.doubleValue() > maxDegree.doubleValue()) {
        maxDegree = agregated;
        clas = i;
        cont = 0;
      } else if (Objects.equals(agregated, maxDegree)) {
        cont++;
      } 
    } 
    if (cont > 0)
      clas = this.defaultRule; 
    int numEltosClass1, numEltosClass0;
    if (((((numEltosClass0 = ((ArrayList)gAsoc.get(0)).size()) == 1) ? 1 : 0) & (((numEltosClass1 = ((ArrayList)gAsoc.get(1)).size()) > 1) ? 1 : 0)) == 0) {
      if ((((numEltosClass0 > 1) ? 1 : 0) & ((numEltosClass1 == 1) ? 1 : 0)) != 0) {
        caso = 0;
        salida[0] = clas;
        salida[1] = caso;
        return salida;
      } 
      if ((((numEltosClass0 > 1) ? 1 : 0) & ((numEltosClass1 > 1) ? 1 : 0)) != 0) {
        int situacion = situacionIntervalos(((Double)Collections.<Double>min(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(0))).doubleValue(), ((Double)Collections.<Double>min(gAsoc.get(1))).doubleValue(), ((Double)Collections.<Double>max(gAsoc.get(1))).doubleValue());
        caso = obtener_caso(situacion, degreeClass[0], degreeClass[1]);
      } 
      salida[0] = clas;
      salida[1] = caso;
      return salida;
    } 
    caso = 0;
    salida[0] = clas;
    salida[1] = caso;
    return salida;
  }
  
  private double RDF(double a, double b, double aut1, double aut2) {
    double x = 0.0D;
    x = Math.pow(Math.abs(Math.pow(a, aut2) - Math.pow(b, aut2)), aut1);
    return x;
  }
  
  private Double agChoquet(ArrayList<Double> asociations, ArrayList<Integer> firRul, double exp, double aut1, double aut2) {
    double[] w = new double[asociations.size()];
    double sumaBi = 0.0D;
    ArrayList<Double> valAux = new ArrayList<>();
    ArrayList<Integer> regAux = new ArrayList<>();
    Object[] valores = asociations.toArray();
    Object[] reglas = firRul.toArray();
    List<Integer> indices = sortValues(asociations);
    Collections.sort(asociations);
    for (int p = 0; p < valores.length; p++) {
      valAux.add((Double)valores[((Integer)indices.get(p)).intValue()]);
      regAux.add((Integer)reglas[((Integer)indices.get(p)).intValue()]);
    } 
    int jotaDirac = ((Integer)regAux.get((int)Math.floor((asociations.size() / 2)))).intValue();
    if (this.tipoFM == 3 || this.tipoFM == 4) {
      Random r = new Random(123456789L);
      double suma = 0.0D;
      int j;
      for (j = 0; j < asociations.size(); j++) {
        w[j] = r.nextDouble();
        suma += w[j];
      } 
      j = 0;
      while (j < asociations.size()) {
        int n = j++;
        w[n] = w[n] / suma;
      } 
    } 
    double sumando = 0.0D;
    regAux.remove(0);
    Double agr = valAux.get(0);
    //System.out.println("0, agr: " + agr);
    for (int i = 1; i < valAux.size(); i++) {
      double d1, div, alpha, Falpha, x = RDF(((Double)valAux.get(i)).doubleValue(), ((Double)valAux.get(i - 1)).doubleValue(), aut1, aut2);
      double y = fuzzyMeasure(regAux, indices, i, jotaDirac, w, exp, asociations);
      switch (this.opFM) {
        case 1:
          sumando = Math.min(x, y);
          break;
        default:
          sumando = x * y;
          break;
        case 3:
          sumando = Math.max(0.0D, x + y - 1.0D);
          break;
        case 4:
          if (x == 0.0D && y == 0.0D) {
            sumando = 0.0D;
            break;
          } 
          sumando = x * y / (x + y - x * y);
          break;
        case 5:
          sumando = Math.min(x * Math.sqrt(y), y * Math.sqrt(x));
          break;
        case 6:
          sumando = Math.min(x, y) * Math.max(Math.pow(x, 2.0D), Math.pow(y, 2.0D));
          break;
        case 7:
          d1 = 0.1D;
          sumando = x * y * (1.0D + d1 * (1.0D - x) * (1.0D - y));
          break;
        case 8:
          sumando = (x * y + Math.min(x, y)) / 2.0D;
          break;
        case 9:
          sumando = Math.sqrt(x * y);
          break;
        case 10:
          if (x == 0.0D || y == 0.0D) {
            sumando = 0.0D;
            break;
          } 
          div = 1.0D / x + 1.0D / y;
          sumando = 2.0D / div;
          break;
        case 11:
          sumando = Math.sin(1.5707963267948966D * Math.pow(x * y, 0.0D));
          break;
        case 12:
          sumando = Math.min((x + 1.0D) * Math.sqrt(y) / 2.0D, y * Math.sqrt(x));
          break;
        case 13:
          sumando = x * y + Math.pow(x, 2.0D) * y * (1.0D - x) * (1.0D - y);
          break;
        case 14:
          sumando = Math.max(Math.min(x, y / 2.0D), x + y - 1.0D);
          break;
        case 15:
          sumando = Math.sqrt(x * (y + 1.0D) / 2.0D);
          break;
        case 16:
          sumando = x * Math.pow(y, 2.0D);
          break;
        case 17:
          sumando = Math.min(x, 1.0D - x + Math.min(x, Math.pow(y, exp)));
          break;
        case 18:
          if (x < y) {
            sumando = x;
            break;
          } 
          sumando = Math.min(x / 2.0D, y);
          break;
        case 19:
          if (x == 0.0D) {
            sumando = 0.0D;
            break;
          } 
          if (x > 0.0D && x <= y) {
            sumando = (x + y) / 2.0D;
            break;
          } 
          sumando = Math.min(x / 2.0D, y);
          break;
        case 20:
          sumando = RDF(Math.min(((Double)valAux.get(i)).doubleValue(), y), Math.min(((Double)valAux.get(i - 1)).doubleValue(), y), aut1, aut2);
          break;
        case 21:
          sumando = RDF(Math.sqrt(((Double)valAux.get(i)).doubleValue() * y), Math.max(0.0D, ((Double)valAux.get(i - 1)).doubleValue() + y - 1.0D), aut1, aut2);
          break;
        case 22:
          sumando = RDF(Math.sqrt(((Double)valAux.get(i)).doubleValue() * (y + 1.0D) / 2.0D), Math.min(((Double)valAux.get(i - 1)).doubleValue(), y), aut1, aut2);
          break;
        case 23:
          sumando = this.RDF(Math.sqrt((Double)valAux.get(i) * (y + 1.0) / 2.0), (Double)valAux.get(i - 1) * Math.pow(y, 2.0), aut1, aut2);
          //sumando = RDF(Math.sqrt(((Double)valAux.get(i)).doubleValue() * (y + 1.0D) / 2.0D), ((Double)valAux.get(i - 1)).doubleValue() * Math.pow(y, 2.0D), aut1, aut2);
          break;
        case 24:
          alpha = 0.1D;
          Falpha = (((Double)valAux.get(i - 1)).doubleValue() < y) ? (alpha * ((Double)valAux.get(i - 1)).doubleValue()) : Math.max(((Double)valAux.get(i - 1)).doubleValue() * alpha, y);
          sumando = RDF(Math.sqrt(((Double)valAux.get(i)).doubleValue() * y), Falpha, aut1, aut2);
          break;
        case 25:
          sumando = RDF(Math.sqrt(((Double)valAux.get(i)).doubleValue() * y), ((Double)valAux.get(i - 1)).doubleValue() * Math.pow(y, 2.0D), aut1, aut2);
          break;
      } 
      sumando = Math.min(1.0D, sumando);
      agr = Double.valueOf(agr.doubleValue() + sumando);
      //System.out.println(i + ", agr: " + agr + ", x: " + x + ", y: " + y + ", sumando: " + sumando);
      regAux.remove(0);
    } 
    return agr;
  }
  
  private double fuzzyMeasure(ArrayList<Integer> rulesIndex, List<Integer> indices, int indAg, int jotaDirac, double[] w, double exp, ArrayList<Double> asociations) {
    int j;
    double wi = 0.0D;
    int numFiredRules = asociations.size();
    double measure = 0.0D;
    switch (this.tipoFM) {
      case 1:
        measure = rulesIndex.size() / numFiredRules;
        return measure;
      case 2:
        if (rulesIndex.contains(Integer.valueOf(jotaDirac))) {
          measure = 1.0D;
        } else {
          measure = 0.0D;
        } 
        return measure;
      case 3:
        for (j = indAg; j < numFiredRules; j++)
          measure += w[((Integer)indices.get(j)).intValue()]; 
        return measure;
      case 4:
        for (j = numFiredRules - 1; j > indAg; j--)
          measure += w[((Integer)indices.get(j)).intValue()]; 
        return measure;
    } 
    measure = Math.pow((double)rulesIndex.size() / numFiredRules, exp);
    return measure;
  }
  
  private List<Integer> sortValues(ArrayList<Double> valores) {
    TreeMap<Double, ArrayList<Integer>> map = new TreeMap<>();
    for (int p = 0; p < valores.size(); p++) {
      ArrayList<Integer> ind = map.get(valores.get(p));
      if (ind == null) {
        ind = new ArrayList<>();
        map.put(valores.get(p), ind);
      } 
      ind.add(Integer.valueOf(p));
    } 
    ArrayList<Integer> indices = new ArrayList<>();
    for (List<? extends Integer> arr : map.values())
      indices.addAll(arr); 
    return indices;
  }
  
  public int hasClassUncovered(int[] selected) {
    int[] cover = new int[this.train.getnClasses()];
    int i;
    for (i = 0; i < cover.length; i++)
      cover[i] = (this.train.numberInstances(i) > 0) ? 0 : 1; 
    for (i = 0; i < this.ruleBase.size(); i++) {
      if (selected[i] > 0) {
        int n = ((Rule)this.ruleBase.get(i)).getClas();
        cover[n] = cover[n] + 1;
      } 
    } 
    int count = 0;
    for (i = 0; i < cover.length; i++) {
      if (cover[i] == 0)
        count++; 
    } 
    return count;
  }
  
  public void reduceRules(int clas) {
    int posBestWracc;
    ArrayList<ExampleWeight> exampleWeight = new ArrayList<>();
    int i;
    for (i = 0; i < this.train.size(); i++)
      exampleWeight.add(new ExampleWeight(this.Ks[this.train.getOutputAsInteger(i)], this.Ws[this.train.getOutputAsInteger(i)])); 
    int[] selected = new int[this.ruleBase.size()];
    for (i = 0; i < this.ruleBase.size(); i++)
      selected[i] = 0; 
    int nExamples = this.train.numberInstances(clas);
    int nRuleSelect = 0;
    System.out.println("Entra en reducir reglas para la clase : " + clas + " con reglas: " + this.ruleBase.size());
    do {
      double bestWracc = -1.0D;
      posBestWracc = -1;
      for (i = 0; i < this.ruleBase.size(); i++) {
        if (selected[i] == 0) {
          Rule rule1 = this.ruleBase.get(i);
          rule1.calculateWracc(this.train, exampleWeight, this.typeAggMatch, this.tuneCut);
          if (rule1.getWracc() > bestWracc) {
            bestWracc = rule1.getWracc();
            posBestWracc = i;
          } 
        } 
      } 
      if (posBestWracc <= -1)
        continue; 
      selected[posBestWracc] = 1;
      nRuleSelect++;
      Rule rule = this.ruleBase.get(posBestWracc);
      nExamples -= rule.reduceWeight(this.train, exampleWeight, this.typeAggMatch, this.tuneCut);
    } while (nExamples > 0 && nRuleSelect < this.ruleBase.size() && posBestWracc > -1);
    System.out.println("Sale de reduce Reglas para la clase: Numero examples: " + nExamples + "/" + this.train.numberInstances(clas) + " Numero de reglas: " + nRuleSelect + "/" + this.ruleBase.size() + " Valor de K: " + this.Ks[clas]);
    for (i = this.ruleBase.size() - 1; i >= 0; i--) {
      if (selected[i] == 0)
        this.ruleBase.remove(i); 
    } 
    exampleWeight.clear();
  }
  
  public void reduceRules() {
    int posBestWracc;
    ArrayList<ExampleWeight> exampleWeight = new ArrayList<>();
    int i;
    for (i = 0; i < this.train.size(); i++)
      exampleWeight.add(new ExampleWeight(this.Ks[this.train.getOutputAsInteger(i)], this.Ws[this.train.getOutputAsInteger(i)])); 
    int[] selected = new int[this.ruleBase.size()];
    for (i = 0; i < this.ruleBase.size(); i++)
      selected[i] = 0; 
    int nExamples = this.train.getnData();
    int nRuleSelect = 0;
    int numRulesNeg = 0;
    int numRulesPos = 0;
    do {
      double bestWracc = -1.0D;
      posBestWracc = -1;
      for (i = 0; i < this.ruleBase.size(); i++) {
        if (selected[i] == 0) {
          Rule rule1 = this.ruleBase.get(i);
          rule1.calculateWracc(this.train, exampleWeight, this.typeAggMatch, this.tuneCut);
          if (rule1.getWracc() > bestWracc) {
            bestWracc = rule1.getWracc();
            posBestWracc = i;
          } 
        } 
      } 
      if (posBestWracc <= -1)
        continue; 
      selected[posBestWracc] = 1;
      nRuleSelect++;
      Rule rule = this.ruleBase.get(posBestWracc);
      if (rule.clas == 0) {
        numRulesPos++;
      } else {
        numRulesNeg++;
      } 
      nExamples -= rule.reduceWeightClass(this.train, exampleWeight, this.typeAggMatch, this.tuneCut);
    } while (nExamples > 0 && nRuleSelect < this.ruleBase.size() && posBestWracc > -1);
    for (i = this.ruleBase.size() - 1; i >= 0; i--) {
      if (selected[i] == 0)
        this.ruleBase.remove(i); 
    } 
    exampleWeight.clear();
  }
  
  public void learnAgregationPerCase(myDataset DS) {
    int[] RDFs = { 0, 0, 0, 2, 2, 2, 2 };
    int[] AGs = { 19, 21, 25, 10, 21, 23, 25 };
    double[] fscores = new double[6];
    double[] maxFscores = new double[6];
    int i;
    for (i = 0; i < 6; i++)
      maxFscores[i] = -1.0D; 
    System.out.println("RDFs: " + Arrays.toString(RDFs));
    System.out.println("AGs: " + Arrays.toString(AGs));
    for (i = 1; i < 3; i++) {
      if (i != 2) {
        System.out.println("MRD: " + i);
        System.out.println("Llamando a stats de los ejemplos con validacion");
        fscores = evaluateDS_stats_learn(DS, i);
        for (int j = 0; j < 6; j++) {
          if (fscores[j] > maxFscores[j])
            maxFscores[j] = fscores[j]; 
        } 
        System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
      } else {
        for (int j = 0; j < 7; j++) {
          System.out.println("MRD: " + i + ", RDF: " + RDFs[j] + ", Ag: " + AGs[j]);
          System.out.println("Llamando a stats de los ejemplos con validacion");
          fscores = evaluateDS_stats_learn(DS, i);
          for (int m = 0; m < 6; m++) {
            if (fscores[m] > maxFscores[m]) {
              maxFscores[m] = fscores[m];
              this.typeRDFs[m] = RDFs[j];
              this.opFMs[m] = AGs[j];
            } 
          } 
          System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
        } 
      } 
    } 
    for (int k = 0; k < 6; k++)
      System.out.println("Caso " + k + ": RDF: " + this.typeRDFs[k] + ", AG: " + this.opFMs[k]); 
  }
  
  public String printString() {
    String[] names = this.train.names();
    String[] clases = this.train.clases();
    String stringOut = new String("");
    int ant = 0;
    int i;
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule r = this.ruleBase.get(i);
      stringOut = stringOut + (i + 1) + ": ";
      int j;
      for (j = 0; j < this.n_variables && r.antecedent[j] < 0; j++);
      if (j < this.n_variables && r.antecedent[j] >= 0) {
        stringOut = stringOut + names[j] + " IS " + r.dataBase.print(j, r.antecedent[j]);
        ant++;
      } 
      j++;
      while (j < this.n_variables - 1) {
        if (r.antecedent[j] >= 0) {
          stringOut = stringOut + " AND " + names[j] + " IS " + r.dataBase.print(j, r.antecedent[j]);
          ant++;
        } 
        j++;
      } 
      if (j < this.n_variables && r.antecedent[j] >= 0) {
        stringOut = stringOut + " AND " + names[j] + " IS " + r.dataBase.print(j, r.antecedent[j]) + ": " + clases[r.clas];
        ant++;
      } else {
        stringOut = stringOut + ": " + clases[r.clas];
      } 
      stringOut = (this.typeRW == 0) ? (stringOut + " CF: " + r.getConfidence() + "\n") : (stringOut + " Lift: " + r.getLift() + "\n");
    } 
    stringOut = stringOut + "\n\n";
    stringOut = stringOut + "@supp, CF and lift:\n\n";
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule rule = this.ruleBase.get(i);
      stringOut = stringOut + (i + 1) + ": ";
      stringOut = stringOut + "supp: " + rule.getSupport() + ", CF: " + rule.getConfidence() + " AND lift: " + rule.getLift() + "\n";
    } 
    stringOut = "@Number of rules: " + this.ruleBase.size() + " Number of Antecedents by rule: " + (ant * 1.0D / this.ruleBase.size()) + "\n\n" + stringOut;
    return stringOut;
  }
  
  public void saveFile(String filename) {
    String stringOut = new String("");
    stringOut = printString();
    Files.writeFile(filename, stringOut);
  }
  
  public int[] getRulesPerClass() {
    int[] rulesEachClass = new int[2];
    int i;
    for (i = 0; i < 2; i++)
      rulesEachClass[i] = 0; 
    for (i = 0; i < this.ruleBase.size(); i++) {
      Rule rule = this.ruleBase.get(i);
      if (rule.clas == 0) {
        rulesEachClass[0] = rulesEachClass[0] + 1;
      } else {
        rulesEachClass[1] = rulesEachClass[1] + 1;
      } 
    } 
    return rulesEachClass;
  }
}
