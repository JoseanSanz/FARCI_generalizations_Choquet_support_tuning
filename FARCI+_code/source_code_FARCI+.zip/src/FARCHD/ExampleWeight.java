package FARCHD;

public class ExampleWeight {
  double weight;
  
  int count;
  
  int K;
  
  public ExampleWeight(int K) {
    this.K = K;
    this.count = 0;
    this.weight = 1.0D;
  }
  
  public ExampleWeight(int K, double w) {
    this.K = K;
    this.count = 0;
    this.weight = w;
  }
  
  public ExampleWeight(double w) {
    this.K = 2;
    this.count = 0;
    this.weight = w;
  }
  
  public void incCount() {
    this.count++;
    this.weight = (this.count >= this.K) ? 0.0D : (1.0D / (this.count + 1.0D));
  }
  
  public int getCount() {
    return this.count;
  }
  
  public boolean isActive() {
    return (this.count < this.K);
  }
  
  public double getWeight() {
    return this.weight;
  }
}
