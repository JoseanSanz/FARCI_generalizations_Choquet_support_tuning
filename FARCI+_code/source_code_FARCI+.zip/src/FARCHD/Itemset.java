package FARCHD;

import java.util.ArrayList;

public class Itemset {
  ArrayList<Item> itemset;
  
  int clas;
  
  double support;
  
  double supportRule;
  
  public Itemset() {}
  
  public Itemset(int clas) {
    this.itemset = new ArrayList<>();
    this.clas = clas;
    this.support = 0.0D;
    this.supportRule = 0.0D;
  }
  
  public Itemset clone() {
    Itemset d = new Itemset(this.clas);
    for (int i = 0; i < this.itemset.size(); i++)
      d.add(((Item)this.itemset.get(i)).clone()); 
    d.clas = this.clas;
    d.support = this.support;
    d.supportRule = this.supportRule;
    return d;
  }
  
  public void add(Item item) {
    this.itemset.add(item);
  }
  
  public Item get(int pos) {
    return this.itemset.get(pos);
  }
  
  public Item remove(int pos) {
    return this.itemset.remove(pos);
  }
  
  public int size() {
    return this.itemset.size();
  }
  
  public double getSupport() {
    return this.support;
  }
  
  public double getSupportClass() {
    return this.supportRule;
  }
  
  public int getClas() {
    return this.clas;
  }
  
  public void setClas(int clas) {
    this.clas = clas;
  }
  
  public boolean isEqual(Itemset a) {
    if (this.itemset.size() != a.size())
      return false; 
    if (this.clas != a.getClas())
      return false; 
    for (int i = 0; i < this.itemset.size(); ) {
      Item item = this.itemset.get(i);
      if (item.isEqual(a.get(i))) {
        i++;
        continue;
      } 
      return false;
    } 
    return true;
  }
  
  public void calculateSupports(DataBase dataBase, myDataset train, int typeAggMatch, int tuneCut) {
    this.support = 0.0;
    this.supportRule = 0.0;
    for (int i = 0; i < train.size(); i++) {
      double degree = degree(dataBase, train.getExample(i), typeAggMatch, tuneCut);
      this.support += degree;
      if (train.getOutputAsInteger(i) == this.clas)
        this.supportRule += degree; 
    } 
    this.support /= (double)train.getnData();
    this.supportRule /= (double)train.getnData();
  }
  
  public double degree(DataBase dataBase, double[] ejemplo) {
    return degreeProduct(dataBase, ejemplo);
  }
  
  public double degree(DataBase dataBase, double[] ejemplo, int typeAggMatch, int tuneCut) {
    return degreeProduct(dataBase, ejemplo, typeAggMatch, tuneCut);
  }
  
  private double degreeProduct(DataBase dataBase, double[] example) {
    Item item;
    double degree = 1.0D;
    for (int i = 0; i < this.itemset.size() && degree > 0.0D; degree *= dataBase.matching(item.getVariable(), item.getValue(), example[item.getVariable()]), i++)
      item = this.itemset.get(i); 
    return degree;
  }
  
  private double degreeProduct(DataBase dataBase, double[] example, int typeAggMatch, int tuneCut) {
    Item item;
    double degree, arithmeticMean = 1.0D;
    if (tuneCut == 1) {
      arithmeticMean = 0.0D;
      double nAnts = 0.0D;
      for (int i = 0; i < this.itemset.size(); i++) {
        item = this.itemset.get(i);
        double machDegree = dataBase.matching(item.getVariable(), item.getValue(), example[item.getVariable()]);
        nAnts++;
        if (machDegree == 0.0D) {
          arithmeticMean = 0.0D;
          break;
        } 
        arithmeticMean += machDegree;
      } 
      arithmeticMean = (float)arithmeticMean / nAnts;
    } 
    if ((((tuneCut == 1) ? 1 : 0) & ((arithmeticMean < dataBase.cut[this.clas]) ? 1 : 0)) != 0) {
      degree = 0.0D;
    } else if (typeAggMatch == 0) {
      degree = 1.0D;
      for (int i = 0; i < this.itemset.size() && degree > 0.0D; degree *= dataBase.matching(item.getVariable(), item.getValue(), example[item.getVariable()]), i++)
        item = this.itemset.get(i); 
    } else if (typeAggMatch == 1) {
      if (tuneCut == 1) {
        degree = arithmeticMean;
      } else {
        degree = 0.0D;
        double nAnts = 0.0D;
        for (int i = 0; i < this.itemset.size(); i++) {
          item = this.itemset.get(i);
          double machDegree = dataBase.matching(item.getVariable(), item.getValue(), example[item.getVariable()]);
          nAnts++;
          if (machDegree == 0.0D) {
            degree = 0.0D;
            break;
          } 
          degree += machDegree;
        } 
        degree = (float)degree / nAnts;
      } 
    } else if (typeAggMatch == 2) {
      degree = 1.0D;
      double nAnts = 0.0D;
      for (int i = 0; i < this.itemset.size() && degree > 0.0D; i++) {
        item = this.itemset.get(i);
        degree *= dataBase.matching(item.getVariable(), item.getValue(), example[item.getVariable()]);
        nAnts++;
      } 
      degree = Math.pow(degree, 1.0D / nAnts);
    } else {
      degree = 0.0D;
      double nAnts = 0.0D;
      for (int i = 0; i < this.itemset.size(); i++) {
        item = this.itemset.get(i);
        double machDegree = dataBase.matching(item.getVariable(), item.getValue(), example[item.getVariable()]);
        nAnts++;
        if (machDegree == 0.0D) {
          degree = 0.0D;
          break;
        } 
        degree += 1.0D / machDegree;
      } 
      if (degree != 0.0D)
        degree = (float)nAnts / degree; 
    } 
    return degree;
  }
}
