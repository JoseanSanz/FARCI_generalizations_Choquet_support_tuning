package FARCHD;

public class Item implements Comparable {
  int variable;
  
  int value;
  
  public Item() {}
  
  public Item(int variable, int value) {
    this.variable = variable;
    this.value = value;
  }
  
  public void setValues(int variable, int value) {
    this.variable = variable;
    this.value = value;
  }
  
  public int getVariable() {
    return this.variable;
  }
  
  public int getValue() {
    return this.value;
  }
  
  public Item clone() {
    Item d = new Item();
    d.variable = this.variable;
    d.value = this.value;
    return d;
  }
  
  public boolean isEqual(Item a) {
    return (this.variable == a.variable && this.value == a.value);
  }
  
  public int compareTo(Object a) {
    if (((Item)a).variable > this.variable)
      return -1; 
    if (((Item)a).variable < this.variable)
      return 1; 
    if (((Item)a).value > this.value)
      return -1; 
    if (((Item)a).value < this.value)
      return 1; 
    return 0;
  }
}
