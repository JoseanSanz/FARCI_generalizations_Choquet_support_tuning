package FARCHD;

import org.core.Randomize;

public class Individual implements Comparable {
  double[] gene;
  
  int[] geneR;
  
  double fitness;
  
  double accuracy;
  
  double w1;
  
  int n_e;
  
  int nGenes;
  
  int tuneCut;
  
  int numGenLat;
  
  int numGenExp;
  
  int numGenRDF;
  
  int numGenSup;
  
  RuleBase ruleBase;
  
  double[][] gInt;
  
  public Individual() {}
  
  public Individual(RuleBase ruleBase, DataBase dataBase, double w1, int tuneCut) {
    this.ruleBase = ruleBase;
    this.w1 = w1;
    this.tuneCut = tuneCut;
    this.fitness = Double.NEGATIVE_INFINITY;
    this.accuracy = 0.0D;
    this.n_e = 0;
    this.numGenLat = dataBase.getnLabelsReal();
    this.numGenExp = this.ruleBase.train.getnClasses();
    this.numGenRDF = 2 * dataBase.numVariables();
    this.numGenSup = dataBase.getnLabelsReal();
    this.nGenes = this.numGenLat;
    
    switch (this.ruleBase.typeInference) {
      case 2:
        this.nGenes += this.numGenExp;
        break;
      case 4:
        this.nGenes += this.numGenExp + this.numGenRDF;
      case 5:
        this.nGenes += this.numGenExp + this.numGenRDF + this.numGenSup;
      case 6:
        this.nGenes += this.numGenExp + this.numGenSup;
      case 7:
        this.nGenes += this.numGenSup;
        break;
    } 
    if (this.tuneCut == 1)
      this.nGenes += 2; 
    if (this.nGenes > 0) {
      this.gene = new double[this.nGenes];
      this.gInt = new double[this.nGenes][];
      int i;
      for (i = 0; i < this.numGenLat; i++) {
        this.gInt[i] = new double[2];
        this.gInt[i][0] = 0.0;
        this.gInt[i][1] = 1.0;
      } 
      this.geneR = new int[this.ruleBase.size()];
      switch (this.ruleBase.typeInference) {
        case 2:
          for (i = this.numGenLat; i < this.numGenLat + this.numGenExp; i++) {
            this.gInt[i] = new double[2];
            this.gInt[i][0] = 0.01;
            this.gInt[i][1] = 1.99;
          } 
          break;
        case 4:
          for (i = this.numGenLat; i < this.numGenLat + this.numGenExp; i++) {
            this.gInt[i] = new double[2];
            this.gInt[i][0] = 0.01;
            this.gInt[i][1] = 1.99;
          } 
          for (i = this.numGenLat + this.numGenExp; i < this.numGenLat + this.numGenExp + this.numGenRDF; i++) {
            this.gInt[i] = new double[2];
            this.gInt[i][0] = 0.00001;
            this.gInt[i][1] = 0.99999;
          } 
          break;
        case 5:
          for (i = this.numGenLat; i < this.numGenLat + this.numGenExp; i++) {
            this.gInt[i] = new double[2];
            this.gInt[i][0] = 0.01;
            this.gInt[i][1] = 1.99;
          } 
          for (i = this.numGenLat + this.numGenExp; i < this.numGenLat + this.numGenExp + this.numGenRDF; i++) {
            this.gInt[i] = new double[2];
            this.gInt[i][0] = 0.00001;
            this.gInt[i][1] = 0.99999;
          } 
          for (i = this.numGenLat + this.numGenExp + this.numGenRDF; i < this.numGenLat + this.numGenExp + this.numGenRDF + this.numGenSup; i++) {
            this.gInt[i] = new double[2];
            this.gInt[i][0] = 0.0;
            this.gInt[i][1] = 1.0;
          } 
          break;
        case 6:
          for (i = this.numGenLat; i < this.numGenLat + this.numGenExp; i++) {
            this.gInt[i] = new double[2];
            this.gInt[i][0] = 0.01;
            this.gInt[i][1] = 1.99;
          } 
          for (i = this.numGenLat + this.numGenExp; i < this.numGenLat + this.numGenExp + this.numGenSup; i++) {
            this.gInt[i] = new double[2];
            this.gInt[i][0] = 0.0;
            this.gInt[i][1] = 1.0;
          } 
          break;
        case 7:
          for (i = this.numGenLat; i < this.numGenLat + this.numGenSup; i++) {
            this.gInt[i] = new double[2];
            this.gInt[i][0] = 0.0;
            this.gInt[i][1] = 1.0;
          } 
          break;
      } 
      if (this.tuneCut == 0)
        for (i = this.numGenLat + this.numGenExp + this.numGenRDF; i < this.nGenes; i++) {
          this.gInt[i] = new double[2];
          this.gInt[i][0] = 0.0;
          this.gInt[i][1] = 1.0;
        }  
    } 
  }
  
  public Individual clone() {
    Individual ind = new Individual();
    ind.ruleBase = this.ruleBase;
    ind.w1 = this.w1;
    ind.tuneCut = this.tuneCut;
    ind.fitness = this.fitness;
    ind.accuracy = this.accuracy;
    ind.n_e = this.n_e;
    ind.nGenes = this.nGenes;
    if (this.nGenes > 0) {
      ind.gene = new double[this.nGenes];
      ind.gInt = new double[this.nGenes][];
      for (int i = 0; i < this.nGenes; i++) {
        ind.gene[i] = this.gene[i];
        ind.gInt[i] = new double[2];
        ind.gInt[i][0] = this.gInt[i][0];
        ind.gInt[i][1] = this.gInt[i][1];
      } 
    } 
    ind.geneR = new int[this.geneR.length];
    for (int j = 0; j < this.geneR.length; j++)
      ind.geneR[j] = this.geneR[j]; 
    return ind;
  }
  
  public void reset() {
    if (this.nGenes > 0)
      if (this.tuneCut != 0) {
        int j;
        for (j = 0; j < this.numGenLat; j++)
          this.gene[j] = 0.5; 
        switch (this.ruleBase.typeInference) {
          case 2:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenExp; j++)
              this.gene[j] = 1.0; 
            break;
          case 4:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenExp; j++)
              this.gene[j] = 1.0; 
            for (j = this.numGenLat + this.numGenExp; j < this.numGenLat + this.numGenExp + this.numGenRDF; j++)
              this.gene[j] = 0.5; 
            break;
          case 5:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenExp; j++)
              this.gene[j] = 1.0; 
            for (j = this.numGenLat + this.numGenExp; j < this.numGenLat + this.numGenExp + this.numGenRDF; j++)
              this.gene[j] = 0.5; 
            for (j = this.numGenLat + this.numGenExp + this.numGenRDF; j < this.numGenLat + this.numGenExp + this.numGenRDF + this.numGenSup; j++)
              this.gene[j] = 0.5; 
            break;
          case 6:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenExp; j++)
              this.gene[j] = 1.0; 
            for (j = this.numGenLat + this.numGenExp; j < this.numGenLat + this.numGenExp + this.numGenSup; j++)
              this.gene[j] = 0.5; 
            break;
          case 7:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenSup; j++)
              this.gene[j] = 0.5; 
            break;
        } 
        for (j = this.numGenLat + this.numGenExp + this.numGenRDF + this.numGenSup; j < this.nGenes; j++)
          this.gene[j] = 0.0; 
      } else {
        int j;
        for (j = 0; j < this.numGenLat; j++)
          this.gene[j] = 0.5; 
        switch (this.ruleBase.typeInference) {
          case 2:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenExp; j++)
              this.gene[j] = 1.0; 
            break;
          case 4:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenExp; j++)
              this.gene[j] = 1.0; 
            for (j = this.numGenLat + this.numGenExp; j < this.numGenLat + this.numGenExp + this.numGenRDF; j++)
              this.gene[j] = 0.5; 
            break;
          case 5:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenExp; j++)
              this.gene[j] = 1.0; 
            for (j = this.numGenLat + this.numGenExp; j < this.numGenLat + this.numGenExp + this.numGenRDF; j++)
              this.gene[j] = 0.5; 
            for (j = this.numGenLat + this.numGenExp + this.numGenRDF; j < this.numGenLat + this.numGenExp + this.numGenRDF + this.numGenSup; j++)
              this.gene[j] = 0.5; 
            break;
          case 6:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenExp; j++)
              this.gene[j] = 1.0; 
            for (j = this.numGenLat + this.numGenExp; j < this.numGenLat + this.numGenExp + this.numGenSup; j++)
              this.gene[j] = 0.5; 
            break;
          case 7:
            for (j = this.numGenLat; j < this.numGenLat + this.numGenSup; j++)
              this.gene[j] = 0.5; 
            break;
        } 
      }  
    for (int i = 0; i < this.geneR.length; i++)
      this.geneR[i] = 1; 
  }
  
  public void randomValues() {
    if (this.nGenes > 0)
      for (int j = 0; j < this.nGenes; j++)
        this.gene[j] = this.gInt[j][0] + (this.gInt[j][1] - this.gInt[j][0]) * Randomize.Rand();  
    for (int i = 0; i < this.geneR.length; i++)
      this.geneR[i] = (Randomize.Rand() < 0.5) ? 0 : 1; 
  }
  
  public void randomValuesLat_RS() {
    if (this.nGenes > 0)
      for (int j = 0; j < this.numGenLat; j++)
        this.gene[j] = this.gInt[j][0] + (this.gInt[j][1] - this.gInt[j][0]) * Randomize.Rand();  
    for (int i = 0; i < this.geneR.length; i++)
      this.geneR[i] = (Randomize.Rand() < 0.5D) ? 0 : 1; 
  }
  
  public void randomValuesExp() {
    if (this.nGenes > 0)
      for (int i = this.numGenLat; i < this.numGenLat + this.numGenExp; i++)
        this.gene[i] = this.gInt[i][0] + (this.gInt[i][1] - this.gInt[i][0]) * Randomize.Rand();  
  }
  
  public void randomValuesRDF() {
    if (this.nGenes > 0)
      for (int i = this.numGenLat + this.numGenExp; i < this.numGenLat + this.numGenExp + this.numGenRDF; i++)
        this.gene[i] = this.gInt[i][0] + (this.gInt[i][1] - this.gInt[i][0]) * Randomize.Rand();  
  }
  
  public void randomValuesSupport() {
    if (this.nGenes > 0)
      for (int i = this.numGenLat + this.numGenExp + this.numGenRDF; i < this.numGenLat + this.numGenExp + this.numGenRDF + this.numGenSup; i++)
        this.gene[i] = this.gInt[i][0] + (this.gInt[i][1] - this.gInt[i][0]) * Randomize.Rand();  
  }
  
  public void randomValuesSupport_6() {
    if (this.nGenes > 0)
      for (int i = this.numGenLat + this.numGenExp; i < this.numGenLat + this.numGenExp + this.numGenSup; i++)
        this.gene[i] = this.gInt[i][0] + (this.gInt[i][1] - this.gInt[i][0]) * Randomize.Rand();  
  }
  
  public void randomValuesSupport_7() {
    if (this.nGenes > 0)
      for (int i = this.numGenLat; i < this.numGenLat + this.numGenSup; i++)
        this.gene[i] = this.gInt[i][0] + (this.gInt[i][1] - this.gInt[i][0]) * Randomize.Rand();  
  }
  
  public int size() {
    return this.geneR.length;
  }
  
  public int getnSelected() {
    int count = 0;
    for (int i = 0; i < this.geneR.length; i++) {
      if (this.geneR[i] > 0)
        count++; 
    } 
    return count;
  }
  
  public boolean isNew() {
    return (this.n_e == 1);
  }
  
  public void onNew() {
    this.n_e = 1;
  }
  
  public void offNew() {
    this.n_e = 0;
  }
  
  public void setw1(double value) {
    this.w1 = value;
  }
  
  public double getAccuracy() {
    return this.accuracy;
  }
  
  public double getFitness() {
    return this.fitness;
  }
  
  private int StringRep(Individual indiv, int BITS_GEN) {
    int length = this.nGenes * BITS_GEN;
    char[] stringIndiv1 = new char[length];
    char[] stringIndiv2 = new char[length];
    char[] stringAux = new char[length];
    double INCREMENTO = 1.0D / (Math.pow(2.0D, BITS_GEN) - 1.0D);
    int pos = 0;
    int i;
    for (i = 0; i < this.nGenes; i++) {
      long n = (int)(this.gene[i] / INCREMENTO + 0.5D);
      int j;
      for (j = BITS_GEN - 1; j >= 0; j--) {
        stringAux[j] = (char)(int)(48L + (n & 0x1L));
        n >>= 1L;
      } 
      char last = '0';
      j = 0;
      while (j < BITS_GEN) {
        if (stringAux[j] != last) {
          stringIndiv1[pos] = '1';
        } else {
          stringIndiv1[pos] = '0';
        } 
        last = stringAux[j];
        j++;
        pos++;
      } 
    } 
    pos = 0;
    for (i = 0; i < this.nGenes; i++) {
      long n = (int)(indiv.gene[i] / INCREMENTO + 0.5D);
      int j;
      for (j = BITS_GEN - 1; j >= 0; j--) {
        stringAux[j] = (char)(int)(48L + (n & 0x1L));
        n >>= 1L;
      } 
      char last = '0';
      j = 0;
      while (j < BITS_GEN) {
        if (stringAux[j] != last) {
          stringIndiv2[pos] = '1';
        } else {
          stringIndiv2[pos] = '0';
        } 
        last = stringAux[j];
        j++;
        pos++;
      } 
    } 
    int count = 0;
    for (i = 0; i < length; i++) {
      if (stringIndiv1[i] != stringIndiv2[i])
        count++; 
    } 
    return count;
  }
  
  public int distHamming(Individual ind, int BITS_GEN) {
    int count = 0;
    for (int i = 0; i < this.geneR.length; i++) {
      if (this.geneR[i] != ind.geneR[i])
        count++; 
    } 
    if (this.nGenes > 0)
      count += StringRep(ind, BITS_GEN); 
    return count;
  }
  
  public void Hux(Individual indiv) {
    int[] position = new int[this.geneR.length];
    int dist = 0;
    int i;
    for (i = 0; i < this.geneR.length; i++) {
      if (this.geneR[i] != indiv.geneR[i]) {
        position[dist] = i;
        dist++;
      } 
    } 
    int nPos = dist / 2;
    for (i = 0; i < nPos; i++) {
      int random = Randomize.Randint(0, dist);
      int aux = this.geneR[position[random]];
      this.geneR[position[random]] = indiv.geneR[position[random]];
      indiv.geneR[position[random]] = aux;
      aux = position[--dist];
      position[dist] = position[random];
      position[random] = aux;
    } 
  }
  
  public void xPC_BLX(Individual indiv, double d) {
    for (int i = 0; i < this.nGenes; i++) {
      double I = d * Math.abs(this.gene[i] - indiv.gene[i]);
      double A1 = this.gene[i] - I;
      if (A1 < 0.0D)
        A1 = 0.0D; 
      double C1;
      if ((C1 = this.gene[i] + I) > 1.0D)
        C1 = 1.0D; 
      this.gene[i] = A1 + Randomize.Rand() * (C1 - A1);
      A1 = indiv.gene[i] - I;
      if (A1 < 0.0D)
        A1 = 0.0D; 
      if ((C1 = indiv.gene[i] + I) > 1.0D)
        C1 = 1.0D; 
      indiv.gene[i] = A1 + Randomize.Rand() * (C1 - A1);
    } 
  }
  
  public RuleBase generateRB() {
    RuleBase ruleBase = this.ruleBase.clone();
    ruleBase.evaluate(this.gene, this.geneR);
    ruleBase.setDefaultRule();
    for (int i = this.geneR.length - 1; i >= 0; i--) {
      if (this.geneR[i] < 1)
        ruleBase.remove(i); 
    } 
    return ruleBase;
  }
  
  public void evaluate() {
    this.ruleBase.evaluate(this.gene, this.geneR);
    this.fitness = this.accuracy = this.ruleBase.getAccuracy();
  }
  
  public int compareTo(Object a) {
    if (((Individual)a).fitness < this.fitness)
      return -1; 
    if (((Individual)a).fitness > this.fitness)
      return 1; 
    return 0;
  }
}
