package FARCHD;

import java.util.ArrayList;
import java.util.StringTokenizer;
import org.core.Fichero;

public class parseParameters {
  private String algorithmName;
  
  private String trainingFile;
  
  private String validationFile;
  
  private String testFile;
  
  private ArrayList<String> inputFiles = new ArrayList<>();
  
  private String outputTrFile;
  
  private String outputTstFile;
  
  private ArrayList<String> outputFiles = new ArrayList<>();
  
  private ArrayList<String> parameters = new ArrayList<>();
  
  public void parseConfigurationFile(String fileName) {
    String file = Fichero.leeFichero(fileName);
    StringTokenizer line = new StringTokenizer(file, "\n\r");
    readName(line);
    readInputFiles(line);
    readOutputFiles(line);
    readAllParameters(line);
  }
  
  private void readName(StringTokenizer line) {
    StringTokenizer data = new StringTokenizer(line.nextToken(), " = \" ");
    data.nextToken();
    this.algorithmName = new String(data.nextToken());
    while (data.hasMoreTokens())
      this.algorithmName += " " + data.nextToken(); 
  }
  
  private void readInputFiles(StringTokenizer line) {
    String new_line = line.nextToken();
    StringTokenizer data = new StringTokenizer(new_line, " = \" ");
    data.nextToken();
    this.trainingFile = data.nextToken();
    this.validationFile = data.nextToken();
    this.testFile = data.nextToken();
    while (data.hasMoreTokens())
      this.inputFiles.add(data.nextToken()); 
  }
  
  private void readOutputFiles(StringTokenizer line) {
    String new_line = line.nextToken();
    StringTokenizer data = new StringTokenizer(new_line, " = \" ");
    data.nextToken();
    this.outputTrFile = data.nextToken();
    this.outputTstFile = data.nextToken();
    while (data.hasMoreTokens())
      this.outputFiles.add(data.nextToken()); 
  }
  
  private void readAllParameters(StringTokenizer line) {
    while (line.hasMoreTokens()) {
      String new_line = line.nextToken();
      StringTokenizer data = new StringTokenizer(new_line, " = ");
      String cadena = new String("");
      while (data.hasMoreTokens())
        cadena = data.nextToken(); 
      this.parameters.add(cadena);
    } 
  }
  
  public String getTrainingInputFile() {
    return this.trainingFile;
  }
  
  public String getTestInputFile() {
    return this.testFile;
  }
  
  public String getValidationInputFile() {
    return this.validationFile;
  }
  
  public String getTrainingOutputFile() {
    return this.outputTrFile;
  }
  
  public String getTestOutputFile() {
    return this.outputTstFile;
  }
  
  public String getAlgorithmName() {
    return this.algorithmName;
  }
  
  public String[] getParameters() {
    String[] param = (String[])this.parameters.toArray();
    return param;
  }
  
  public String getParameter(int pos) {
    return this.parameters.get(pos);
  }
  
  public String[] getInputFiles() {
    return (String[])this.inputFiles.toArray();
  }
  
  public String getInputFile(int pos) {
    return this.inputFiles.get(pos);
  }
  
  public String[] getOutputFiles() {
    return (String[])this.outputFiles.toArray();
  }
  
  public String getOutputFile(int pos) {
    return this.outputFiles.get(pos);
  }
}
