package FARCHD;

import java.util.ArrayList;

public class Apriori {
  ArrayList<Itemset> L2;
  
  double minsup;
  
  double minconf;
  
  double[] minSupps;
  
  int nClasses;
  
  int nVariables;
  
  int depth;
  
  int typeQuality;
  
  int typeAggMatch;
  
  int tuneCut;
  
  int tipoFM;
  
  int opFM;
  
  long ruleStage1;
  
  RuleBase ruleBase;
  
  RuleBase ruleBaseClase;
  
  myDataset train;
  
  DataBase dataBase;
  
  public Apriori() {}
  
  public Apriori(RuleBase ruleBase, DataBase dataBase, myDataset train, double minsup, double minconf, int depth, int typeQuality, int typeAggMatch, int tuneCut, int tipoFM, int opFM) {
    this.train = train;
    this.dataBase = dataBase;
    this.ruleBase = ruleBase;
    this.minconf = minconf;
    this.depth = depth;
    this.typeQuality = typeQuality;
    this.typeAggMatch = typeAggMatch;
    this.tuneCut = tuneCut;
    this.tipoFM = tipoFM;
    this.opFM = opFM;
    this.nClasses = this.train.getnClasses();
    this.nVariables = this.train.getnInputs();
    this.L2 = new ArrayList<>();
    this.minSupps = new double[this.nClasses];
    for (int i = 0; i < this.nClasses; i++)
      this.minSupps[i] = this.train.frecuentClass(i) * minsup; 
  }
  
  public int[] generateRB() {
    int[] rC = new int[2];
    this.ruleStage1 = 0L;
    this.ruleBaseClase = new RuleBase(this.dataBase, this.train, this.ruleBase.getK(), this.ruleBase.getTypeInference(), this.ruleBase.getTypeAggMatch(), this.ruleBase.getTypeRW(), this.tuneCut, this.tipoFM, this.opFM);
    for (int i = 0; i < this.nClasses; i++) {
      this.minsup = this.minSupps[i];
      generateL2(i);
      generateLarge(this.L2, i);
      this.ruleBase.add(this.ruleBaseClase);
      this.ruleBaseClase.clear();
    } 
    rC = this.ruleBase.getRulesPerClass();
    this.ruleBase.reduceRules();
    return rC;
  }
  
  private void generateL2(int clas) {
    this.L2.clear();
    Itemset itemset = new Itemset(clas);
    for (int i = 0; i < this.nVariables; i++) {
      if (this.dataBase.numLabels(i) > 1)
        for (int j = 0; j < this.dataBase.numLabels(i); j++) {
          Item item = new Item(i, j);
          itemset.add(item);
          itemset.calculateSupports(this.dataBase, this.train, this.typeAggMatch, this.tuneCut);
          if (itemset.getSupportClass() >= this.minsup)
            this.L2.add(itemset.clone()); 
          itemset.remove(0);
        }  
    } 
    generateRules(this.L2, clas);
  }
  
  public int hasUncoverClass(int clas) {
    int uncover = 0;
    for (int j = 0; j < this.train.size(); j++) {
      if (this.train.getOutputAsInteger(j) == clas) {
        boolean stop = false;
        for (int i = 0; i < this.L2.size() && !stop; i++) {
          Itemset itemset = this.L2.get(i);
          double degree = itemset.degree(this.dataBase, this.train.getExample(j), this.typeAggMatch, this.tuneCut);
          if (degree > 0.0D)
            stop = true; 
        } 
        if (!stop)
          uncover++; 
      } 
    } 
    return uncover;
  }
  
  private void generateLarge(ArrayList<Itemset> Lk, int clas) {
    int size = Lk.size();
    if (size > 1 && ((Itemset)Lk.get(0)).size() < this.nVariables && ((Itemset)Lk.get(0)).size() < this.depth) {
      ArrayList<Itemset> Lnew = new ArrayList<>();
      for (int i = 0; i < size - 1; i++) {
        Itemset itemseti = Lk.get(i);
        for (int j = i + 1; j < size; j++) {
          Itemset itemsetj = Lk.get(j);
          if (isCombinable(itemseti, itemsetj)) {
            Itemset newItemset = itemseti.clone();
            newItemset.add(itemsetj.get(itemsetj.size() - 1).clone());
            newItemset.calculateSupports(this.dataBase, this.train, this.typeAggMatch, this.tuneCut);
            if (newItemset.getSupportClass() >= this.minsup)
              Lnew.add(newItemset); 
          } 
        } 
        generateRules(Lnew, clas);
        generateLarge(Lnew, clas);
        Lnew.clear();
      } 
    } 
  }
  
  private boolean isCombinable(Itemset itemseti, Itemset itemsetj) {
    Item itemi = itemseti.get(itemseti.size() - 1);
    Item itemj = itemsetj.get(itemseti.size() - 1);
    return (itemi.getVariable() < itemj.getVariable());
  }
  
  public long getRulesStage1() {
    return this.ruleStage1;
  }
  
  private void generateRules(ArrayList<Itemset> Lk, int clas) {
    for (int i = Lk.size() - 1; i >= 0; i--) {
      double lift, confidence;
      Itemset itemset = Lk.get(i);
      if (itemset.getSupport() > 0.0D) {
        confidence = itemset.getSupportClass() / itemset.getSupport();
        lift = itemset.getSupportClass() / (itemset.getSupport() * this.train.frecuentClass(clas));
      } else {
        confidence = 0.0D;
        lift = 0.0D;
      } 
      if (this.typeQuality == 0) {
        if (confidence > 0.4D) {
          this.ruleBaseClase.add(itemset);
          this.ruleStage1++;
        } 
        if (confidence > this.minconf)
          Lk.remove(i); 
      } else if (lift > 1.0D) {
        this.ruleBaseClase.add(itemset);
        this.ruleStage1++;
        Lk.remove(i);
      } 
    } 
    if (this.ruleBaseClase.size() > 500000) {
      this.ruleBaseClase.reduceRules(clas);
      System.out.println("Number of rules: " + this.ruleBase.size());
    } 
  }
}
